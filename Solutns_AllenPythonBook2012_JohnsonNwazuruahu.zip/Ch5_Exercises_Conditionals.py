
#CHAPTER 5 EXERCISES

#1. Assume the days of the week are numbered 0,1,2,3,4,5,6 from Sunday to Saturday. Write
#a function which is given the day number, and it returns the day name (a string).
#SOLN

def day_name(n):
    if n == 0:
        print("sunday")
    elif n == 1:
        print("monday")
    elif n == 2:
        print("tuesday")
    elif n == 3:
        print("wednesday")
    elif n == 4:
        print("thursday")
    elif n == 5:
        print("friday")
    elif n == 6:
        print("saturday")
    else:
        print("Please enter a number between 0 and 6")


day_name(10)

##
#2. You go on a wonderful holiday, leaving
# on day number 3 (a Wednesday). You return home after 137 sleeps. Write a general
# version of the program which asks for the starting day number, and the length of your
# stay, and it will tell you the name of day of the week you will return on.
#SOLN

#A week has 7 days. so, any number of days you are away for, add it to day you travelled and divide answer by 7.
#whatsoever is the remainder, that is the day you will return ust look for its day number equivalent and you are done!

#def getting_return_day(start_day, length_of_stay):
start_day = int(float(input("What day number are you starting your holiday? ")))
length_of_stay = int(float(input("How many nights are you gonna be gone for? ")))
days_in_a_week = 7
return_day = (start_day + length_of_stay) % days_in_a_week

if return_day == 0:
    print("sunday")
elif return_day == 1:
    print("monday")
elif return_day == 2:
    print("tuesday")
elif return_day == 3:
    print("wednesday")
elif return_day == 4:
    print("thursday")
elif return_day == 5:
    print("friday")
else:
    print("saturday")



# 3. Give logical opposites of below:
#. (a) a > b ;      (b) a >= b;     (c) a >= 18 and day == 3;    (d) a >= 18 and day != 3
#SOLN

#(a) a > b  ==  a <= b             a >= b  ==  a < b
#(c) a >= 18 and day == 3   IS      (a >= 18)  OR  (day ==3)
#(d) a >= 18 and day != 3   IS      (a >= 18)  OR  (!=3)


#4. What do these expressions evaluate to?
# (a) 3 == 3        (b) 3 != 3      (c) 3 >= 4      (d) not (3 < 4)
#SOLN
# (a) 3 == 3  evaluates to True       (b) 3 != 3  evaluates to False
# (c) 3 >= 4  evaluates to False      (d) not (3 < 4)  evaluates to False



# 6. Write a function which is given an exam mark, and it returns a string — the grade for
#that mark — according to this scheme:
#Mark, Grade = >= 75, First; [70-75), Upper Second;  [60-70), Second;   [50-60), Third;
#               [45-50), F1 Supp;   [40-45), F2;        < 40, F3
# The square and round brackets denote closed and open intervals. A closed interval includes
# the number, and open interval excludes it. So 39.99999 gets grade F3, but 40 gets grade F2.
# Assume xs = [83, 75, 74.9, 70, 69.9, 65, 60, 59.9, 55, 50, 49.9, 45, 44.9, 40, 39.9, 2, 0]
#Test your function by printing the mark and the grade for all the elements in this list.

#SOLN

def exam_grade(mark):
    """ Function that accepts an exam mark 'm' and gives the grade accordingly"""
    if mark >= 75:
        print("First")
    elif mark >= 70 and mark < 75:
        print("Upper Second")
    elif mark >= 60 and mark < 70:
        print("Second")
    elif mark >= 50 and mark < 60:
        print("Third")
    elif mark >= 45 and mark < 50:
        print("F1 Supp")
    elif mark >= 40 and mark < 45:
        print("F2")
    else:
        print("F3")

#Test list
xs = [83, 75, 74.9, 70, 69.9, 65, 60, 59.9, 55, 50, 49.9, 45, 44.9, 40, 39.9, 2, 0]
for m in xs:
    exam_grade(m)

#proper input to function
#mark = float(input("What is your exam mark?" ))
exam_grade(float(input("What is your exam mark?" )))




# 7. Modify the turtle bar chart program so that the pen is up for the small gaps between each bar.
#SOLN

import turtle

playgrd = turtle.Screen()
playgrd.bgcolor("light green")
playgrd.title("drawing bar charts")

xs2 = [48, 117, 200, 240, 160, 260, 220]
color_fill = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"]

def draw_bar_chart(t, w, q):
    """ A fn to draw a bar chart t, with different bars of length l and same width w"""

    t.color("blue", "red")
    t.pensize(3)
    t.penup()   #next 3 ines moves the pen to left by 200units for a better centralized  drawing on canvas
    t.forward(-50)
    t.pendown()
    for v in xs2:
        t.begin_fill()
        t.left(90)
        t.forward(v)
        t.write("  " + str(v))
        t.right(90)
        t.forward(w)
        t.right(90)
        t.forward(v)
        t.left(90)
        t.end_fill()
        t.penup()       # addition to make pen go up in between the bars
        t.forward(q)
        t.pendown()


jman = turtle.Turtle()
draw_bar_chart(jman, 40, 10)

#playgrd.mainloop()





# 8. Modify the turtle bar chart program so that the bar for any value of 200 or more is filled
# with red, values between [100 and 200) are filled with yellow, and bars representing
# values less than 100 are filled with green.

def draw_bar_chart(t,):
    """ A fn to draw a bar chart t, with different bars of length l and same width w"""

    t.pensize(3)
    t.penup()               #next 6 ines moves the pen to a new position b4 drawing starts
    t.forward(-50)         #(i.e. left by 200units and downwards by 300units.
    t.right(90)
    t.forward(300)
    t.left(90)
    t.pendown()

    def bar_pattern(w, q):      #this fuction encapsulates the actual block of code which performs 4 actions viz
        t.begin_fill()          #1) draws the bars, 2)gets them ready for color fill, 3)displays their value and
        t.left(90)              # then 4)makes pen jump by a certain number of units after drawing bar!
        t.forward(v)            #Reason for creating the function is so that we can simply repeat them
        t.write("  " + str(v))  # when we set the condition for color fill operation
        t.right(90)
        t.forward(w)
        t.right(90)
        t.forward(v)
        t.left(90)
        t.end_fill()
        t.penup()       # addition to make pen go up in between the bars
        t.forward(q)
        t.pendown()


    for v in xs2:           #Time to start iterating over each value and drawing their bar
        if v >= 200:                #sets condition for color fill to be used for each bar
            t.color("blue", "red")
            bar_pattern(40, 10)

        elif v >= 100 and v < 200:
            t.color("blue", "yellow")
            bar_pattern(40,10)

        else:
            t.color("blue", "green")
            bar_pattern(40, 10)


jman2 = turtle.Turtle()
draw_bar_chart(jman2)

#playgrd.mainloop()




#9. In the turtle bar chart program, what do you expect to happen if one or more of the data
# values in the list is negative? Try it out. Change the program so that when it prints the
# text value for the negative bars, it puts the text below the bottom of the bar.
#SOLN
# When one of the data values is negative, it draws the bar chart in the negative y axis instead, as
# opposed to current +ve y axis where it draws them earlier.

# To make it print the text value below the bar bottom above, we change the location of the t.write command
# from present 4th line to . This is shown in below. I have adjusted the fill command to fill with blue for -ve values!

xs3 = [48, 117, -200, 240, 160, 260, 220, -50]
def draw_bar_chart(t,):
    """ A fn to draw a bar chart t, with different bars of length l and same width w"""

    t.pensize(3)
    t.penup()               #next 6 ines moves the pen to a new position b4 drawing starts
    t.forward(-450)         #(i.e. left by 200units and downwards by 300units.
    t.right(90)
    t.forward(200)
    t.left(90)
    t.pendown()

    def bar_pattern(w, q):
        t.begin_fill()
        t.left(90)
        t.forward(v)
        t.write("  " + str(v))
        t.right(90)
        t.forward(w)
        t.right(90)
        t.forward(v)
        t.left(90)
        t.end_fill()
        t.penup()       # addition to make pen go up in between the bars
        t.forward(q)
        t.pendown()

    def neg_bar_pattern(w, q):
        t.begin_fill()
        t.left(90)
        t.forward(v)
        t.right(90)
        t.forward(w)
        t.write("  " + str(v))
        t.right(90)
        t.forward(v)
        t.left(90)
        t.end_fill()
        t.penup()       # addition to make pen go up in between the bars
        t.forward(q)
        t.pendown()



    for v in xs3:           #Time to start iterating over each value and drawing their bar
        if v >= 200:                #sets condition for color fill to be used for each bar
            t.color("blue", "red")
            bar_pattern(40, 10)

        elif v >= 100 and v < 200:
            t.color("blue", "yellow")
            bar_pattern(40,10)

        elif v >= 0 and v < 100:
            t.color("blue", "green")
            bar_pattern(40, 10)
        else:
            t.color("blue", "violet")
            neg_bar_pattern(40,10)


jman3 = turtle.Turtle()
draw_bar_chart(jman3)

playgrd.mainloop()




# 10. Write a function find_hypot which, given the length of two sides of a right-angled
#triangle, returns the length of the hypotenuse. (Hint: x ** 0.5 will return the square root.)

#Soln
#This would just be a function that takes 2 arguments. I.e. a function with two parameters where
# parameter1 would refer to the "Oppposite" and parameter2 = "adjacent"

def find_hypot(o, a):
    """ Function to find hypotenuse of a right-angled triangle when supplied with opp 'o' and
    adj 'a'"""
    hypotenuse = ((o**2) + (a**2))**0.5
    print(hypotenuse)


find_hypot(3, 4)




#11.Write a function is_rightangled which, given the length of three sides of a triangle,
# will determine whether the triangle is right-angled. Assume that the third argument to
# the function is always the longest side. It will return True if the triangle is right-angled,
#or False otherwise.
# Hint: Floating point arithmetic is not always exactly accurate, so it is not safe to test
#floating point numbers for equality. If a good programmer wants to know whether x is
# equal or close enough to y, they would probably code it up as:
# if abs(x-y) < 0.000001: # If x is approximately equal to y...

#SOLN
#Well, our triangle with known 3 sides would be right-angled if the sum of square of the shorter
# two sides equal square of the longest side, which is the hypotenus. since a*2 + b*2 = c*2 (c = hypotenuse)!

#Since we are assuming the last side is the hypothenus, then we have

def is_rightangled(a, b, c):
    """ A fn to test if a triangle is right angled, where a, b, c are opp, adj and hyp respectively"""

    if ((a**2) + (b**2)) == c**2:
        print("True")
    else:
        print("False")


is_rightangled(3, 4, 5)

#12.Extend the above program so that the sides can be given to the function in any order.

#SOLN

def is_rightangled(a, b, c):
    """ A fn to test if a triangle is right angled, where a, b, c are opp, adj and hyp respectively"""

    if a > b and a > c:
        if ((b**2) + (c**2)) == a**2:
            print("True")
        else:
            print("False")
    elif b > a and b > c:
        if ((a**2) + (c**2)) == b**2:
            print("True")
        else:
            print("False")
    elif c > a and c > a:
        if ((a**2) + (b**2)) == c**2:
            print("True")
        else:
            print("False")
    else:
        pass

is_rightangled(4, 5, 3)


#       OR WE CAN USE THE MAX FUNCTION VIZ

def is_rightangled(a, b, c):
    """ A fn to test if a triangle is right angled, where a, b, c are opp, adj and hyp respectively"""

    longest = max(a, b, c)

    if a == longest:
        if ((b**2) + (c**2)) == a**2:
            print("True")
        else:
            print("False")
    elif b  == longest:
        if ((a**2) + (c**2)) == b**2:
            print("True")
        else:
            print("False")
    elif c == longest:
        if ((a**2) + (b**2)) == c**2:
            print("True")
        else:
            print("False")
    else:
        pass

is_rightangled(3, 8, 6)






