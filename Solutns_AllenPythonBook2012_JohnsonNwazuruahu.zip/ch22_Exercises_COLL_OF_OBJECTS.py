




#   1.
# Modify cmp so that Aces are ranked higher than Kings.
#SOLN
# JUST CHANGE REVERSE THE EQUALITY SIGN FOR RANK COMPARISON VIS
'''
    Instead of this:
                if self.rank > other.rank:
                return 1
            elif self.rank < other.rank:
                return -1
    You have this:
                if self.rank < other.rank:
                return 1
            elif self.rank > other.rank:
                return -1
'''



#   22.2
#Claaa for Cards
class Cards:
    # define some class attributes
    suits = ["Clubs", "Diamonds", "Hearts", "Spades"]
    ranks = ["narf", "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack",
             "Queen", "King"]

    # def init method to create objects and initialize them with their attributes
    def __init__(self, suit=0, rank=0):
        self.suit = suit
        self.rank = rank

    #       22.3
    # produce a strg rep of object using class and object attributes
    def __str__(self):
        return (self.ranks[self.rank] + " of " + self.suits[self.suit])

    # 22.4  COMPARING CARDS
    def cmp(self, other):
        if self.suit > other.suit:
            return 1
        elif self.suit < other.suit:
            return -1
        else:           # suits are same, so check rank
            if self.rank < other.rank:
                return 1
            elif self.rank > other.rank:
                return -1
            else:       # objects are completely equal, so return 1
                return 0


    # Operating overloading for each of the comparison operations
    def __gt__(self, other):
        return self.cmp(other) > 0
    def __eq__(self, other):
        return self.cmp(other) == 0
    def __lt__(self, other):
        return self.cmp(other) < 0
    def __ge__(self, other):
        return self.cmp(other) >= 0
    def __le__(self, other):
        return self.cmp(other) <= 0
    def __ne__(self, other):
        return self.cmp(other) != 0



ace_of_spades = Cards(3, 1);        print(ace_of_spades);
king_of_spades = Cards(3, 13);      print(king_of_spades)
three_of_clubs = Cards(0, 3)
four_of_clubs = Cards(0, 4)
jack_of_diamonds = Cards(1, 11)
king_of_diamonds = Cards(1, 13)

print(ace_of_spades > king_of_spades)       # returns True. cos now, ace is greater than king, for  cards of equal suit
print(three_of_clubs > four_of_clubs)       # returns True. cos now, 3 is greater than 4
print(three_of_clubs < four_of_clubs)           # returns False. cos now, 3 is greater than 4
print(king_of_diamonds < jack_of_diamonds)      # returns True. cos now, jack is greater than king

