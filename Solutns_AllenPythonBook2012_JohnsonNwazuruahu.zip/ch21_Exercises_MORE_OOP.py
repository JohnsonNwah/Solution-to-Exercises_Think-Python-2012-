
#   1.
'''
    Write a Boolean function 'between' that takes two MyTime objects, t1 and t2,
    as arguments, and returns True if the invoking object falls between the two
    times. Assume t1 <= t2, and make the test closed at the lower bound and
    open at the upper bound, i.e. return True if t1 <= obj < t2.
'''
# SOLN
#   Steps to Solve;
# 1.    Turn all timeobjects to seconds (u can use to_seconds fn).
# 2.    Do comparisons accordingly


# First define a fn that produces a seconds-only rep of any given time
def seconds_only(t):
    """ Fn turns any time object into a seconds-only rep"""
    (h, m, s) = t
    hr_sec = h * 3600
    min_sec = m * 60
    total_sec = hr_sec + min_sec + s
    return(total_sec)

#Then write ur function accordingly
def between(t3, t1, t2):
    """ t3 time object is checked if it's inbetween t1 and t2 objects. Returns
    True if it is"""

    t3_secs = seconds_only(t3)
    t1_secs = seconds_only(t1)
    t2_secs = seconds_only(t2)

    return t3_secs > t1_secs and t3_secs <= t2_secs

#test
#time3 = (6, 0, 1)
#time1 = (3,0,0)
#time2 = (6, 0, 0)
#print(between(time3, time1, time2))







#   2.
#Turn the above function into a method in the MyTime class.

class NewTime:

    #   21.5    Aha! Insight
    def __init__(self, h, m, s):
        """ Init method takes hour, minutes and seconds of any size, converts
        them all to secnds first and then starts converting them back, starting
        from hour"""
        h_to_sec = h * 3600
        m_to_sec = m * 60
        total_sec = h_to_sec + m_to_sec + s
        self.totalsecs = total_sec
        self.hour = total_sec // 3600
        rem_secs_hrdiv = total_sec % 3600
        self.minutes = rem_secs_hrdiv // 60
        rem_secs_mindiv = rem_secs_hrdiv % 60
        self.seconds = rem_secs_mindiv


    def __str__(self):
        """ Fn to produce a string rep of the NewTime object"""
        return "{0}:{1}:{2}:".format(self.hour, self.minutes, self.seconds)

    #Fn to convert any given time (h, m, t) to seconds
    def to_seconds(self):
        """" Fn converts given time to seconds. Returns a seconds-only
        representation of given time."""
        return self.totalsecs


    # Fn to add time
    def add_time(self, time_to_add):
        """ Fn adds given time (time_to_add) to an initial time (self) and
        returns the result as a new NewTime object. All time are first converted
        to second using the to_seconds method earlier defined"""
        current_time = self.to_seconds() + time_to_add.to_seconds()
        return NewTime(0, 0, current_time)

    # Fn to substract time, to get time elapsed between t1 and t2
    def substract_time(self, time_now):
        """ Fn substracts initial time (self) from current time (time_now) and
        returns the result as a new NewTime object. All time are first converted
        to second using the to_seconds method earlier defined"""
        time_elapsed = time_now.to_seconds() - self.to_seconds()
        return NewTime(0, 0, time_elapsed)

    # Function to multiply given time by a given integar no and produce result
    def mult_by_int(self,x):
        self_in_secs = self.to_seconds()        #changes self to seconds
        multiplied_time = self_in_secs * x      #x must be an integar
        #now, return a new instantiated object as result
        return NewTime(0, 0, multiplied_time)


    #   21.7    "AFTER" CHECK
    def after(self, t2):
        """ Fn to check if t1 (self) is after t2 (time 2)"""
        #convert both to seconds and check
        return self.to_seconds() > t2.to_seconds()

    #   21.8    OPERATOR OVERLOADING
    def __mul__(self, other):
        """ Overloading the multiplication operator"""
        return NewTime(0, 0, self.to_seconds() * other.to_seconds())

        # Operator overloading
    def __sub__(self, other):
         """ Overloading the substraction operator"""
         return NewTime(0, 0, other.to_seconds() - self.to_seconds())

    #   EXERCISE 2
    def between_time(self, t1, t2):
        """ Fn returns True if self is in between t1 and t2 time objects"""
        self_secs = self.to_seconds()       #converts time to seconds
        t1_secs = t1.to_seconds()           #converts time to seconds
        t2_secs = t2.to_seconds()           #converts time to seconds
        return(self_secs > t1_secs and self_secs <= t2_secs)

    #   EXERCISE 3
    # Overload the necessary operator(s) so that instead of having to write
    # if t1.after(t2): ... we can use the more convenient...if t1 > t2: ...
    # SOLN
    # We use the builtin gt method (i.e. greater than)
    def __gt__(self, other):
        """ Fn to check if t1 (self) is after t2 (time 2)"""
        #convert both to seconds and check
        return self.to_seconds() > other.to_seconds()


    #   EXERCISE 4
    #Rewrite increment as a method that uses our â€œAhaâ€ insight.
    #Recall, increment function adds seconds only to a MyTime object
    def increment(self, secs):
        """ Fn to add secs to a given object and produce a new object with
        added seconds"""
        #first convert time to seconds. then add specified seconds.
        #finally return a new Time object summed seconds
        new_secs = self.to_seconds() + secs
        return NewTime(0, 0, new_secs)      #return new Time object


    #   EXERCISE 5
    #Create some test cases for the increment method. Consider specifically the
    # case where the number of seconds to add to the time is negative.
    #Fix up increment so that it handles this case if it does not do so already.
    #(You may assume that you will never subtract more seconds than are in the
    # time object.)

    #SOLN
    #Increment fn only handles negative additions. we only need to ensure
    #seconds being substracted never exceeds what's in the self object.
    def increment_check(self, secs):
        """ Fn to add secs to a given object and produce a new object with
        added seconds"""
        #first convert time to seconds. then add specified seconds.
        #finally return a new Time object summed seconds
        if self.to_seconds() >= abs(secs):
            new_secs = self.to_seconds() + secs
        else:
            return ("You can't substract beyond current time value")
        return NewTime(0, 0, new_secs)      #return new Time object


#test
time3 = NewTime(2, 0, 0)
time1 = NewTime(3,0,0)
time2 = NewTime(6, 0, 0)

print(time3.between_time(time1, time2))
print(time2 > time3)
print(time2.increment(-7200))
print(time2.increment_check(-21500))






# Overload the necessary operator(s) so that instead of having to write
''' if t1.after(t2): ...
    we can use the more convenient
    if t1 > t2: ...
'''











