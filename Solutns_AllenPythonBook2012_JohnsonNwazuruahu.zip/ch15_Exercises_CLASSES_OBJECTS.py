

#   1.
''' Rewrite the distance function from the chapter titled Fruitful functions so
    that it takes two Points as parameters instead of four numbers, i.e. this function
            def distance(x1, y1, x2, y2):
            dx = x2 - x1
            dy = y2 - y1
            return 0.0'''
#SOLN:
#By two Points, we believe this means, two objects. each object having its x, y
#coordinates aggregated to it via a class.
'''Steps:
    1) Define ur class, having two attributes (x and y) to be assigned to the points
    2) include ur strg method, to turn the instances to strings
    2) define a function inside the class (method) to compute distances. Now, the
        trick is to specify the other point, alao, in the normal notation. it's
        value would be fetched from "outside the class"
    3) print ur result and check with various values, against fn above.
'''

#class def
class cl_distance:
    """ A class to represent and find distance of two points"""

    def __init__(self, x, y):
        """ Method to specify and set up atributes of each point"""
        self.x = x
        self.y = y

    def __str__(self):
        """Method to turn instances to strings"""
        return "{0}, {1}".format(self.x, self.y)

    def fn_distance(self, point_b):
        """ Fn to find the difference between the points and return same.
        The two points are used as the arguments."""
        dist_x = point_b.x - self.x
        dist_y = point_b.y - self.y
        distance = (((dist_x ** 2) + (dist_y ** 2)) ** 0.5)
        return (distance)

#create the instances
point_a = cl_distance(1, 2)        #set x, y coord for pointa: x1 = 1 and y1 = 2
point_b = cl_distance(4, 6)        #set x, y coord for pointa: x1 = 4 and y1 = 6
#print(point_a.x)


#diff = point_a.fn_distance(point_b)
#print("Question 1 answer: ", diff)                          #test of question 1







#   2.
'''
    Add a method reflect_x to Point which returns a new Point, one which is the
    reflection of the point about the x-axis. For example, Point(3, 5).reflect_x()
    is (3, -5)'''
#SOLN
'''
'''
class Point:
    """ Class to represent and manipulate x, y axis"""

    def __init__(self, x, y):
        """ Specify and set-up the attributes of the objects"""
        self.x = x
        self.y = y

    def __str__(self):
        return "{0}, {1}".format(self.x, self.y)

    def reflect_x(self):
        return -(self.x), self.y

    #Answer to QUESTION 3: SLOPE OF LINE
    def slope_from_origin(self):
        return self.y/self.x

    #ANSWER TO QUESTION 4:  FINDING EQUATION OF A STRAIGHT LINE (given only 2 points)
    def get_line_to(self, other_point):
        """ Method finds equation of a straight line, when point instance is
        given a second point. Equation is y = mx+c. Formula used are
        slope(m) = (y2-y1)/(x2-x1) and c (y_intercept) = y1 - mx1"""
        slope = int((other_point.y - self.y)/(other_point.x - self.x))
        y_intercept = self.y - (slope * self.x)
        return slope, y_intercept




p = Point(4, 11)
other_point = Point(6, 15)

'''
print("Question 2 answer: ", Point(4, 5).reflect_x())               #test of question 2
print("Question 3 answer: ",Point(5, 6).slope_from_origin())        #test of question 3
#print(Point(4, 11).get_line_to(Point(6, 15)))                      #test of question 4
print("Question 4 answer: ",Point(4, 11).get_line_to(other_point))  #test of question 4
'''


#   3.
''' Add a method slope_from_origin which returns the slope of the line joining the
    origin to the point. For example, Point(4, 10).slope_from_origin() will give 2.5.
    What cases will cause this method to fail?'''
#SOLN
''' Slope is given by (y-0)/(x-0). basically, a dvision of y value by x value.
    Answer is added to above function.

    WHEN WILL IT FAIL?  It'll fail when both x and y are zero, as it would amount
    to divisiob by zero'''







#   4.
''' The equation of a straight line is â€œy = ax + bâ€, (or perhaps â€œy = mx + câ€).
    The coefficients a and b completely describe the line. Write a method in the
    Point class so that if a point instance is given another point, it will
    compute the equation of the straight line joining the two points.
    It must return the two coefficients as a tuple of two values. For example,
    print(Point(4, 11).get_line_to(Point(6, 15))) should give (2, 3).
    This tells us that the equation of the line joining the two points is
    â€œy = 2x + 3â€. When will this method fail?'''
#SOLN
''' The mathematics behind this is given below.:
    1) Straight line equation:  Y = MX + C
    2)M = slope and is solved by (y2-y1)/(x2-x1)
    3) C= Y intercept. Since, we do not know this by merely looking at given points,
    it's gotten thus; C = y1 - M.x1
    4) So, we'll just implement the two steps to get my answer
    5) EQUATION IS IMPLEMENTED IN CLASS FUNCTION AS REQUIRED.'''







#   5.
''' Given four points that fall on the circumference of a circle, find the
    midpoint of the circle. When will this function fail?
    Hint: You must know how to solve the geometry problem before you think of going
    anywhere near programming. You cannot program a solution to a problem if you donâ€™t
    understand what you want the computer to do!'''
#SOLN
'''
    This is purely using Maths. I'll check the formula and return to solve later'''






#   6.
''' Create a new class, SMS_store. The class will instantiate SMS_store objects,
    similar to an inbox or outbox on a cellphone:
    my_inbox = SMS_store()
    This store can hold multiple SMS messages (i.e. its internal state will
    just be a list of messages). Each message will be represented as a tuple:
    (has_been_viewed, from_number, time_arrived, text_of_SMS)

    The inbox object should provide these methods:

    my_inbox.add_new_arrival(from_number, time_arrived, text_of_SMS)
    # Makes new SMS tuple, inserts it after other messages
    # in the store. When creating this message, its
    # has_been_viewed status is set False.

    my_inbox.message_count()
    # Returns the number of sms messages in my_inbox

    my_inbox.get_unread_indexes()
    # Returns list of indexes of all not-yet-viewed SMS messages

    my_inbox.get_message(i)
    # Return (from_number, time_arrived, text_of_sms) for message[i]
    # Also change its state to "has been viewed".
    # If there is no message at position i, return None

    my_inbox.delete(i) # Delete the message at index i
    my_inbox.clear() # Delete all messages from inbox

    Write the class, create a message store object, write tests for these methods, and implement
    the methods.'''
#SOLN

class SMS_store:
    """ A class to instatntiate sms store, similar to what obtains in an inbox
    or outbox on a cellphone"""

    #Create the attributes; i.e. the message features as stated above
    def __init__(self, has_been_viewed, from_number, time_arrived, text_of_SMS):
        """ Specify and set the object attributes"""
        self.has_been_viewed = has_been_viewed
        self.from_number = from_number
        self.time_arrived = time_arrived
        self.text_of_SMS = text_of_SMS

    #Make them representable as strings
    def __str__(self):
        return "{0}, {1}, {2}, {3}".format(self.has_been_viewed, self.from_number,
                        self.time_arrived, self.text_of_SMS)

    #first method
    def add_new_arrival(self, from_number, time_arrived, text_of_SMS):
        """ Method to make new SMS tuple. """

    #2nd method
    def message_count(self):
        """  # Returns the number of sms messages in my_inbox"""


    #3rd method
    def get_unread_indexes(self, i):
        """Returns list of indexes of all not-yet-viewed SMS messages"""

    #4th method
    def get_message(i):
        """ Return (from_number, time_arrived, text_of_sms) for message[i].
        Also change its state to "has been viewed".
        If there is no message at position i, return None"""

    #5th method
    def delete(i):
        """ Delete the message at index i"""

    #6th method
    def clear():
        """Delete all messages from inbox"""


























