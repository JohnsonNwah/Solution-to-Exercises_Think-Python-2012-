

julia = ("Julia", "Roberts", 1967, "Duplicity", 2009, "Actress", "Atlanta",)

# 9.1
#Supports, same sequence operations like strings. eg indexing, length, concatenation
#Test of sequence operations above

stmt1 = ("This", "year", "is", 2017)
stmt2 = (2016, "is", "gone!", "forever")
stmt3 = ("ENJOY", 2017, "!!!")


test_indexng = stmt1[1];                            print(test_indexng, end="\t")
test_indexng2 = stmt2[:3];                          print(test_indexng2, end="\t")
test_indexng3 = stmt3[:];                           print(test_indexng3)


test_length1 = len(stmt1);                          print(test_length1)
test_length2 = len(test_indexng2);                  print(test_length2)

test_concant1 = stmt1 + stmt2 + stmt3;              print(test_concant1)
#test_concant2 = stmt3[0] + stmt1[1] + stmt3[1:];    print(test_concant2)




#9.2
#Tuple of variables CAN REFER TO tuple of values, in order.
# example from web
# Create a pair of tuples
t1 = 1,2
t2 = "A","B"

# Concatenate and print them
t3 = t1 + t2
print(t3)

# Unpack the tuple and print
# individual elements
w,x,y,z = t3
print(w)
print(x)
print(y)
print(z)

# Create and print a list
L1 = ["a","b","c","d","e"]
print(L1)

# Unpack tuple into the list
# and print it
L1[0],L1[1],L1[2],L1[3] = t3
print(L1)


#First review the basics of tuples and their expressivity in python
b, c, d = a = 1, 2, 3
print(a, b, c, d)

u = ("Johnson", "Amina", "Esther")      #Tuple Packing
v = ("Ft1", "Ft2", "SL")
u = v                           #Tuple unpacking
print(u)




