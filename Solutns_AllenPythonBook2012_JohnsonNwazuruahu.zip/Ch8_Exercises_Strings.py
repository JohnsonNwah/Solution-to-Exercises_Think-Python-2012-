
#1. 1. What is the result of each of the following:
# "Python"[1]                                       =           "y"
# "Strings are sequences of characters."[5]         =           'g'
# len("wonderful")                                  =           9
# "Mystery"[:4]                                     =           'Myst'
# "p" in "Pineapple"                                =           True
# "apple" in "Pineapple"                            =           True
# "pear" not in "Pineapple"                         =           True
# "apple" > "pineapple"                             =           False
# "pineapple" < "Peach"                             =           False




# 2. Modify program below so that Ouack and Quack are spelled correctly.
#1   prefixes = "JKLMNOPQ"
#2 suffix = "ack"
#3
#4 for letter in prefixes:
#5 print(letter + suffix)

#SOLN
prefixes = "JKLMNOPQ"
suffix = "ack"
for letter in prefixes:
    if letter in 'O' or letter in 'Q':
        print(letter + "u" + suffix)
    else:
        print(letter + suffix)





# 3.    Encapsulate below program in a function named count_letters, and generalize it so that it accepts the string and
# the letter as arguments. Make the function return the number of characters, rather than
# print the answer. The caller should do the printing.

#1 fruit = "banana"
#2 count = 0
#3 for char in fruit:
#4 if char == "a":
#5 count += 1
#6 print(count)

#SOLN
def count_letters(x, y):
    """ A fn that transverses a string 'x' and prints no of times a character 'y'
    occurs in that string"""
    counter = 0
    for i in x:
        if y in i:
            counter += 1
    return counter


test_ex3 = count_letters("Count how many times this letter occurs", "c")
print(test_ex3)






# 4.    Now rewrite the count_letters function so that instead of traversing the string, it
# repeatedly calls the find method, with the optional third parameter to locate new occurrences
# of the letter being counted.

#QSTN NOT UNDERSTOOD!






# 5.    Assign to a variable in your program a triple-quoted string that contains your favourite
# paragraph of text—perhaps a poem, a speech, instructions to bake a cake, some inspirational
# verses, etc.
# Now, Write a function which removes all punctuation from the string, breaks the string into
# a list of words, and counts the number of words in your text that contain the letter “e”.
# Your program should print an analysis of the text like this:
# Your text contains 243 words, of which 109 (44.8%) contain an "e".

#SOLN
fav_quote = """One reason so few of us achieve what we truly want is that
            we never direct our focus; we never concentrate our power.
            Most people dabble their way through life,
            never deciding to master anything in particular."""

import string

def percent_letter(x):
    """ A fn that that looks through a string and performs instructions in ex5"""

    #First, we import string module, so we can use its punctuation method = done above.

    #next, remove punctuations (we use for loop) to get a final variable without_punct
    #which has no punctuation
    without_punct = ""
    for i in x:
        if i not in string.punctuation:
            without_punct = without_punct + i

    print(without_punct)        #This is here to test this step, if correct. shld be removed later.

    #next, split without_punct into list of its words
    split_without_punct = without_punct.split()

    print(split_without_punct)   # This is here to check if this step is correct

    #next, count number of words in whole list
    no_of_words = len(split_without_punct)

    #next, tranverse through each word and check if it contains letter e
    #use while loop this time around
    counter_for_loop = 0
    counter_for_e = 0
    while counter_for_loop < no_of_words:                   # this ensures we iterate a no of ties as the no of words in the text
        if 'e' in split_without_punct[counter_for_loop]:    #this checks e in every element (or word) in the list
            counter_for_e += 1              #counter is incremeted anytime word contains e
        counter_for_loop += 1               #increments the while counter after each check for e, to help loop exit

    print(counter_for_e)                    #to check our loop
    print(counter_for_loop)                 #to check our loop


    #next, let's get our value to be used to reference %of occurence of e in total word
    ratio_of_e =(float(counter_for_e)/float(no_of_words)) * 100

    print(ratio_of_e)                   #checks this step


    #finally, use format method to embed all the values inside a string
    analysis = "Your text contains {0} words, of which {1} ({3:.1f}%) contain an \"e\".".format(
                no_of_words, counter_for_e, ratio_of_e, ratio_of_e )

    print(analysis)


percent_letter(fav_quote)





# 6.    Print out a neatly formatted multiplication table, up to 12 x 12.
#SOLN









