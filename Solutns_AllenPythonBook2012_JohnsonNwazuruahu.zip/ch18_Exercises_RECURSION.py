
import turtle
import time

#   18.8
# Modify the Koch fractal program so that it draws a Koch snowflake, like this:
screen = turtle.Screen()
screen.title("Fractal Drawing")
screen.bgcolor("light green")

# Create turtle object
turtle_obj = turtle.Turtle()
turtle_obj.pensize(2)
turtle_obj.pencolor("blue")


def fractal_drawing(t_obj, fractal_order, size):
    """ Function to recursively draw fractal orders"""

    # Base Case...
    if fractal_order == 0:
        t_obj.forward(size)
    else:
        for angle in (60, -120, 60, 120):
            fractal_drawing(t_obj, fractal_order-1, size/3)
            t_obj.left(angle)





fractal_drawing(turtle_obj, 2, 100)




screen.mainloop()






# 19.2  RAISING OUR OWN EXCEPTIONS
def get_age():
    """ Gn to raise our own exceptions"""
    age = int(input("Please enter your age: "))
    if age < 0:
        exceptn_object = ValueError("{0} is not a valid age".format(age))
        raise exceptn_object
    return age


print(get_age())



'''
turtle_obj.forward(50)
turtle_obj.left(60)
turtle_obj.forward(50)
turtle_obj.left(-120)
turtle_obj.forward(50)
turtle_obj.left(60)
turtle_obj.forward(50)
turtle_obj.left(120)
'''