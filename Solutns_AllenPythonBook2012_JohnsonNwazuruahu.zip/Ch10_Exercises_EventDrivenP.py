
#Ex 1.
# 1. Add some new key bindings to the first sample program:
#   • Pressing keys R, G or B should change tess’ color to Red, Green or Blue.
#   • Pressing keys + or - should increase or decrease the width of tess’ pen.
#       Ensure that the pen size stays between 1 and 20 (inclusive).
#   • Handle some other keys to change some attributes of tess, or attributes of
#       the window, or to give her new behaviour that can be controlled
#       from the keyboard.

#SOLN

import turtle
turtle.setup(400,500) # Determine the window size
wn = turtle.Screen() # Get a reference to the window
wn.title("Handling keypresses!") # Change the window title
wn.bgcolor("lightgreen") # Set the background color
tess = turtle.Turtle() # Create our favorite turtle

# The next four functions are our "event handlers".
#Eventhandlers: Programs which contain actions to perform when the event happens
def h1():
    tess.forward(30)

def h2():
    tess.left(45)

def h3():
    tess.right(45)

def h4():
    wn.bye()        # Close down the turtle window

#NEW ADDITIONS FOR EXERCISE
# RGB colors
def h5():
    tess.color("red")

def h6():
    tess.color("green")

def h7():
    tess.color("blue")

#Width increase/decrease
def h8():
    tess.pensize(10)

def h9():
    tess.pensize(5)


# These lines "wire up" keypresses to the handlers weÃ¢â‚¬â„¢ve defined.
# These bind the events handlers to the events
wn.onkey(h1, "Up")
wn.onkey(h2, "Left")
wn.onkey(h3, "Right")
wn.onkey(h4, "q")
wn.onkey(h5, "R")           #From this line down are key bindings for exercise1
wn.onkey(h6, "G")
wn.onkey(h7, "B")
wn.onkey(h8, "plus")
wn.onkey(h9, "-")


# Now we need to tell the window to start listening for events,
# If any of the keys that weÃ¢â‚¬â„¢re monitoring is pressed, its
# handler will be called.
wn.listen()         #This is the main loop pr event loops.
wn.mainloop()





#   Ex 2.
#   2. Change the traffic light program so that changes occur automatically, driven by a timer.
# SOLN.
#Steps I used in tackling this are:
# 1) I created light housing (as a function and ran it)
# 2) I created 3 turtles to represent the 3 lights place them inside the
#       housing at appropriate locations and hid them. (Used a fn for ds step)
# 3) I created my event handler to; track states and then show the appropriate
#       light (turtle) for that state.
# 4) I created event dispatcher and placed same inside the evengt handler, to
#       ensure continuous repetation
# 5) I ran event handler alone and then implemented my main loop.


import turtle

#Create reference to application window and tush it
wdw = turtle.Screen()
wdw.title("My timer event test program")
wdw.bgcolor("yellow")

#   STEP1:
# Create housing for your lights: a combination of 3 sides of a rect and half circle
jman = turtle.Turtle()

#jman.hideturtle()
def traffic_light_house():
    jman.pensize(3)
    jman.color("blue", "light blue")
    jman.begin_fill()
    jman.forward(80)
    jman.left(90)
    jman.forward(220)
    jman.circle(40, 180)
    jman.forward(220)
    jman.left(90)
    jman.end_fill()

traffic_light_house()           #run the function


# STEP 2
#Create the 3 lights as seperate turtles and place them in appropriate location
# in the housing
jman1 = turtle.Turtle()             #for 1st light
jman2 = turtle.Turtle()             #for 2nd light
jman3 = turtle.Turtle()             #for 3rd light
def state_func(x, y, z):
    """ fn to capture each state colour and location; x = forward mvt; y = colour"""
    x.hideturtle()
    x.penup()
    x.forward(40)
    x.left(90)
    x.forward(y)
    x.pendown
    x.shape("circle")
    x.shapesize(3)
    x.fillcolor(z)

state_func(jman1, 40, "Green")              #next 3 lines supply our function
state_func(jman2, 120, "Orange")                #with arguments for each light
state_func(jman3, 200, "Red")


# STEP 3.
#Create event handler, which uses GV and IS to track states and cause transition
# to succesive state
tracking_variable = 1           # my global variable

def state_transitions():
   """ Fn to start transit from first state above and continualy move tru
    other states in order of succesion viz; st1 TO st2 TO st3 TO st1 etc"""
   global tracking_variable        #to allow us use and also modify this
                                    # in this local program
   if tracking_variable == 1:      # this confirms we are in state 1
        jman3.hideturtle()          # this hides immediate last state during transition
        jman1.showturtle()          # show our current state
        tracking_variable = 2

   elif tracking_variable == 2:         # this confirms we are in state 2
        jman1.hideturtle()
        jman2.showturtle()
        tracking_variable = 3

   else:                              # this confirms we are in state 3
        jman2.hideturtle()
        jman3.showturtle()
        tracking_variable = 1

   wdw.ontimer(state_transitions, "3000")       #binder placed here to ensure repetition

state_transitions()                 #then run event handler alone

wdw.mainloop()





# EXERCISE 3: STATIC SOLUTION

import turtle

#Create reference to application window and tush it
wdw = turtle.Screen()
wdw.title("My timer event test program")
wdw.bgcolor("yellow")

#Create housing for your lights: a combination of 3 sides of a rect and half circle
jman = turtle.Turtle()

def traffic_light_house():
    jman.pensize(3)
    jman.color("blue", "light blue")
    jman.begin_fill()
    jman.forward(80)
    jman.left(90)
    jman.forward(250)
    jman.circle(40, 180)
    jman.forward(250)
    jman.left(90)
    jman.end_fill()

traffic_light_house()

# Determine 1st state and its features..
#I'm choosing red as first state, to be placed on below of shape
#first, move turtle to position where to begin drawing
jman.penup()
jman.forward(40)
jman.left(90)
jman.forward(60)
#jman.down()

#start drawing shape for 1st state
jman.shape("circle")
jman.shapesize(3)
jman.fillcolor("red")

#time to start transitions

#create variable to track current statesn

tracking_variable = 1

def state_transitions():
    """ Fn to start transit from first state above and continualy move tru
    other states in order of succesion viz; st1 TO st2 TO st3 TO st1 etc"""
    global tracking_variable        #to allow us use and also modify this
                                    # in this local program
    if tracking_variable == 1:      # this confirms we are in state 1
        jman.forward(80)            #having confirmed we are in 1, now we ask to move to 2
        jman.fillcolor("orange")
        tracking_variable = 2
    elif tracking_variable == 2:    # this confirms we are in state 2
        jman.forward(80)            #having confirmed we are in 2, now we ask to move to 3
        jman.fillcolor("green")
        tracking_variable = 3
    else:                           # this confirms we are in state 3
        jman.forward(-160)            #having confirmed we are in 3, now we ask to move back to 1
        jman.fillcolor("red")
        tracking_variable = 1


#time to bind our events and their handler
wdw.onkey(state_transitions, "4")


#sent up event dispatcher
wdw.listen()            #added cos we are talking keypress event here
wdw.mainloop()



#EXERCISE 3:    DYNAMIC IMPLEMNETAION SOLUTION


import turtle

#Create reference to application window and tush it
wdw = turtle.Screen()
wdw.title("My timer event test program")
wdw.bgcolor("yellow")

#Create housing for your lights: a combination of 3 sides of a rect and half circle
jman = turtle.Turtle()

def traffic_light_house():
    jman.pensize(3)
    jman.color("blue", "light blue")
    jman.begin_fill()
    jman.forward(80)
    jman.left(90)
    jman.forward(250)
    jman.circle(40, 180)
    jman.forward(250)
    jman.left(90)
    jman.end_fill()

traffic_light_house()

# Determine 1st state and its features..
#I'm choosing red as first state, to be placed on below of shape
#first, move turtle to position where to begin drawing
jman.penup()
jman.forward(40)
jman.left(90)
jman.forward(60)
#jman.down()

#start drawing shape for 1st state
#jman.shape("circle")
#jman.shapesize(3)
#jman.fillcolor("red")

#time to start transitions

#create variable to track current statesn

tracking_variable = 1

def state_transitions():
    """ Fn to start transit from first state above and continualy move tru
    other states in order of succesion viz; st1 TO st2 TO st3 TO st1 etc"""
    global tracking_variable        #to allow us use and also modify this
                                    # in this local program
    if tracking_variable == 1:      # this confirms we are in state 1
        #jman.forward(80)            #having confirmed we are in 1, now we ask to move to 2
        jman.shape("circle")
        jman.shapesize(3)
        jman.fillcolor("green")
        #jman.fillcolor("orange")
        tracking_variable = 2
        wdw.ontimer(state_transitions, 3000)
    elif tracking_variable == 2:    # this confirms we are in state 2
        jman.forward(80)            #having confirmed we are in 2, now we ask to move to 3
        jman.fillcolor("orange")
        tracking_variable = 3
        wdw.ontimer(state_transitions, 3000)
    elif tracking_variable == 3:                           # this confirms we are in state 3
        jman.forward(80)            #having confirmed we are in 3, now we ask to move back to 1
        jman.fillcolor("red")
        tracking_variable = 0
        wdw.ontimer(state_transitions, 3000)
    else:
        jman.forward(-160)
        jman.fillcolor("green")
        tracking_variable = 1
        wdw.ontimer(state_transitions, 0)

#time to bind our events and their handler
#wdw.onkey(state_transitions, "4")


state_transitions()

#sent up event dispatcher
#wdw.listen()            #added cos we are talking keypress event here
wdw.mainloop()






# Exercise  5       STATIC SOLUTION
import turtle

#Create reference to application window and tush it
wdw = turtle.Screen()
wdw.title("My timer event test program")
wdw.bgcolor("yellow")

#   STEP1:
# Create housing for your lights: a combination of 3 sides of a rect and half circle
jman = turtle.Turtle()          # turtle for drawing the house


def traffic_light_house():
    jman.pensize(3)
    jman.color("blue", "light blue")
    jman.begin_fill()
    jman.forward(80)
    jman.left(90)
    jman.forward(220)
    jman.circle(40, 180)
    jman.forward(220)
    jman.left(90)
    jman.end_fill()

traffic_light_house()           #run the function


# STEP 2
#Create the 3 turtles for the lights as seperate turtles and place them in
# appropriate location in the housing
jman1 = turtle.Turtle()             #for 1st light
jman2 = turtle.Turtle()             #for 2nd light
jman3 = turtle.Turtle()             #for 3rd light

def light_locations(x, y, z):           #Fn for shape, color creation and placement
    """ Fn to place each turtle in appropriate location"""
    x.hideturtle()
    x.penup()
    x.forward(40)
    x.left(90)
    x. forward(y)
    x.pendown()
    x.shape("circle")
    x.shapesize(3)
    x.fillcolor(z)


light_locations(jman1, 40, "green")
jman1.showturtle()              # this statement makes our default state active
light_locations(jman2, 130, "orange")
light_locations(jman3, 210, "red")


# STEP 3. time to create event handler for required product

state_tracker = 0

def state_transitions():
    """ Fn to transit through our states and implement product reqmt"""
    global state_tracker

    if state_tracker == 0:
        jman3.hideturtle()
        jman1.showturtle()
        wdw.ontimer(state_transitions, 3000)
        state_tracker = 1
    elif state_tracker == 1:
        jman2.showturtle()
        wdw.ontimer(state_transitions, 3000)
        state_tracker = 2
    elif state_tracker == 2:
        jman1.hideturtle()
        wdw.ontimer(state_transitions, 3000)
        state_tracker = 3
    else:
        jman2.hideturtle()
        jman3.showturtle()
        wdw.ontimer(state_transitions, 3000)
        state_tracker = 0

state_transitions()

wdw.mainloop()




# Exercise  5:      DYNAMIC SOLUTION
import turtle

#Create reference to application window and tush it
wdw = turtle.Screen()
wdw.title("My timer event test program")
wdw.bgcolor("yellow")

#   STEP1:
# Create housing for your lights: a combination of 3 sides of a rect and half circle
jman = turtle.Turtle()          # turtle for drawing the house


def traffic_light_house():
    jman.pensize(3)
    jman.color("blue", "light blue")
    jman.begin_fill()
    jman.forward(80)
    jman.left(90)
    jman.forward(220)
    jman.circle(40, 180)
    jman.forward(220)
    jman.left(90)
    jman.end_fill()

traffic_light_house()           #run the function


# STEP 2
#Create the 1 turtle for the deafult STAP and place them in
# appropriate location in the housing
jman1 = turtle.Turtle()             #for 1st light
#jman2 = turtle.Turtle()             #for 2nd light
#jman3 = turtle.Turtle()             #for 3rd light

#def light_locations(x, y, z):           #Fn for shape, color creation and placement
 #   """ Fn to place each turtle in appropriate location"""
jman1.penup()
jman1.forward(40)
jman1.left(90)
jman1.forward(40)
#jman1.pendown()
jman1.shape("circle")
jman1.shapesize(3)
jman1.fillcolor("green")

#We need an extra turtle to make it possible for two turtles to exist at same time
#we'll create and give this turtle color orange
jman2 = turtle.Turtle()
jman2.hideturtle()
jman2.penup()
jman2.forward(40)
jman2.left(90)
jman2.forward(120)
#jman1.pendown()
jman2.shape("circle")
jman2.shapesize(3)
jman2.fillcolor("orange")

# STEP 3. time to create event handler for required product

state_tracker = 0

def state_transitions():
    """ Fn to transit through our states and implement product reqmt"""
    global state_tracker

    if state_tracker == 0:          # g + o
        jman2.showturtle()
        wdw.ontimer(state_transitions, 2000)
        state_tracker = 1
    elif state_tracker == 1:                #o
        jman1.hideturtle()
        wdw.ontimer(state_transitions, 2000)
        state_tracker = 2
    elif state_tracker == 2:           # r
        jman2.hideturtle()
        jman1.showturtle()
        jman1.forward(180)
        jman1.fillcolor("red")
        wdw.ontimer(state_transitions, 5000)
        state_tracker = 3
    else:                       #g
        jman1.forward(-180)
        jman1.fillcolor("green")
        wdw.ontimer(state_transitions, 5000)
        state_tracker = 0

state_transitions()


wdw.mainloop()






# Exercise  5:      DYNAMIC SOLUTION (2) : CONTAINS EXTRA IF STMT
import turtle

#Create reference to application window and tush it
wdw = turtle.Screen()
wdw.title("My timer event test program")
wdw.bgcolor("yellow")

#   STEP1:
# Create housing for your lights: a combination of 3 sides of a rect and half circle
jman = turtle.Turtle()          # turtle for drawing the house


def traffic_light_house():
    jman.pensize(3)
    jman.color("blue", "light blue")
    jman.begin_fill()
    jman.forward(80)
    jman.left(90)
    jman.forward(220)
    jman.circle(40, 180)
    jman.forward(220)
    jman.left(90)
    jman.end_fill()

traffic_light_house()           #run the function


# STEP 2
#Create the 1 turtle for the deafult STAP and place them in
# appropriate location in the housing
jman1 = turtle.Turtle()             #for 1st light
#jman2 = turtle.Turtle()             #for 2nd light
#jman3 = turtle.Turtle()             #for 3rd light

#def light_locations(x, y, z):           #Fn for shape, color creation and placement
 #   """ Fn to place each turtle in appropriate location"""
jman1.penup()
jman1.forward(40)
jman1.left(90)
jman1.forward(40)
#jman1.pendown()
jman1.shape("circle")
jman1.shapesize(3)
jman1.fillcolor("green")

#We need an extra turtle to make it possible for two turtles to exist at same time
#we'll create and give this turtle color orange
#jman2 = turtle.Turtle()
#jman2.hideturtle()
#jman2.penup()
#jman2.forward(40)
#jman2.left(90)
#jman2.forward(120)
#jman1.pendown()
#jman2.shape("circle")
#jman2.shapesize(3)
#jman2.fillcolor("orange")

# STEP 3. time to create event handler for required product

state_tracker = 0

def state_transitions():
    """ Fn to transit through our states and implement product reqmt"""
    global state_tracker

    if state_tracker == 0:          # g for 5mins
        #jman1.forward(90)
        #jman1.fillcolor("orange")
        wdw.ontimer(state_transitions, 5000)
        state_tracker = 1
    elif state_tracker == 1:                #become o
        jman1.forward(90)
        jman1.fillcolor("orange")
        wdw.ontimer(state_transitions, 2000)
        state_tracker = 2
    elif state_tracker == 2:           # r
        jman1.forward(90)
        jman1.fillcolor("red")
        wdw.ontimer(state_transitions, 5000)
        state_tracker = 3
    elif state_tracker == 3:                      #o
        jman1.forward(-90)
        jman1.fillcolor("orange")
        wdw.ontimer(state_transitions, 2000)
        state_tracker = 4
    else:
        jman1.forward(-90)
        jman1.fillcolor("green")
        state_tracker = 0
        wdw.ontimer(state_transitions, 0)

state_transitions()


wdw.mainloop()







