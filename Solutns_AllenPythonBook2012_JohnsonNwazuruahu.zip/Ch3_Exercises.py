
# Chapter 3 Exercises

# 1. Write a program that prints We like Pythonâ€™s turtles! 1000 times.
#Soln:
for i in range(1000):
    a = "We like Python's turtles!"
    print(a)


# 2. Give three attributes of your cellphone object. Give three methods of your cellphone.
#Soln:
#Attributes= Off, On, Silent       Methods = Make a Call, Send SMS, Ring out


#3 Write a program that uses a for loop to print
#One of the months of the year is January
#One of the months of the year is February
#...
#Soln:

mths = ["January", "February", "March", "April", "May", "Jnue", "July",
        "August", "September", "October", "November", "December"]
for m in mths:
    gen_statmt = "One of the months of the year is " + m
    print(gen_statmt)


#4. Suppose our turtle tess is at heading 0 â€” facing east. We execute the statement ...
#... tess.left(3645). What does tess do, and what is her final heading?
#Soln:
# Initial position is 0, facing east.
#final position is 3645 degrees in left direction.
# tess would be facing 45degrees NE.  i.e. 3645 % 360 = 10 r 45 degree.
#The 45 degree is the differential movt leftward.
#If it was rigght movt, it would have been 45degree SE



#5. Assume you have the assignment xs = [12, 10, 32, 3, 66, 17, 42, 99, 20]
#(a) Write a loop that prints each of the numbers on a new line.
#(b) Write a loop that prints each number and its square on a new line.
#(c) Write a loop that adds all the numbers from the list into a variable called total. You
#should set the total variable to have the value 0 before you start adding them up,
#and print the value in total after the loop has completed.
#(d) Print the product of all the numbers in the list. (product means all multiplied together)

#Soln
#a
xs = [12, 10, 32, 3, 66, 17, 42, 99, 20]
for a in xs:
    print(a)

#b
for b in xs:
    numberitself = b
    square = b ** 2
    bothN_S = numberitself, square
    print(bothN_S)

#c
total = 0
for c in xs:                    #not ok
    total = total + c
    print(total)

#d
prodct = 1
for d in xs:
    prodct = prodct * d
    print(prodct)



#6. Use for loops to make a turtle draw these regular polygons (regular means all sides the
# same lengths, all angles the same):
#â€¢ An equilateral triangle, â€¢ A square, â€¢ A hexagon (six sides), â€¢ An octagon (eight sides)
#Soln

#First let's load the turtle module and then create our playground
import turtle
playgrd = turtle.Screen()
playgrd.title("Johnson's Turtle Exercise")
playgrd.bgcolor("yellow")

#An enquilateral triangle
eqTrg = turtle.Turtle()
eqTrg.color("red")
eqTrg.pensize(2)

for e in range(3):
    eqTrg.forward(100)
    eqTrg.left(120)

#a Square
sqr = turtle.Turtle()
sqr.color("blue")
sqr.pensize(4)
sqr.penup()
sqr.forward(200)
sqr.pendown()

for f in range(4):
    sqr.forward(150)
    sqr.left(90)


#a hexagon
hexagn = turtle.Turtle()
hexagn.color("green")
hexagn.pensize(6)
hexagn.penup()
hexagn.forward(-300)
hexagn.pendown()

for f in range(6):
    hexagn.forward(150)
    hexagn.left(60)



#an octagon
octagn = turtle.Turtle()
octagn.color("purple")
octagn.pensize(6)
octagn.penup()
octagn.forward(-100)
octagn.right(90)
octagn.forward(100)
octagn.pendown()

for g in range(8):
    octagn.forward(130)
    octagn.left(45)








