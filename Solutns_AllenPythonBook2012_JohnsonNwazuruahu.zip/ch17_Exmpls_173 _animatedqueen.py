
# SPRITES: ANIMATED NOW (via applying updates)

import pygame, sys, time


vg_screen = pygame.display.set_mode((640, 640))
pygame.display.set_caption("First try at Programming Sprites")

# Now, set up game elements
# GE 1 - small rectangle
permutation = [6, 4, 2, 0, 5, 7, 1, 3]
bd_sz = 640
no_of_sq = len(permutation)  # our permutation list
sq_sz = bd_sz // no_of_sq
col_alternator = 0
x_coord = 0
y_coord = 0
colours = [(255, 255, 0), (0, 0, 192)]  # Set up two colours to be used on chessboard
#gravity = 0.00001
gravity = 0.005

# GE 2: our queens
queen = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\chess_queen.jpg"
queen_SO = pygame.image.load(queen)      #create queen surface object


class QueenSprite:
    """ A class to set up blueprints for building Queen object's attributes and methods"""
    # instantiate the objects
    def __init__(self, image, target_positn):
        self.image = image
        self.target_positn = target_positn
        (x, y) = target_positn
        self.posn = (x, 0)  # Start ball at top of its column
        self.y_velocity = 0  # with zero initial velocity

    # Create a string rep
    def __str__(self):
        return "{0}, {1}, {2}".format(self.image, self.init_positn, self.fnl_positn)

    # Create an update method to update the queens
    def update_sprite(self):
        self.y_velocity += gravity  # Gravity changes velocity
        (x, y) = self.posn          # initial position... i.e top of chessboard
        new_y_pos = y + self.y_velocity  # Velocity moves the ball
        #self.posn = (x, new_y_pos)  # to this new position.  # used for fall that never settles
        # this implements bounce and settle aspect
        (target_x, target_y) = self.target_positn  # Unpack the position
        dist_to_go = target_y - new_y_pos  # How far to our floor?

        if dist_to_go < 0:  # Are we under floor?
            self.y_velocity = -0.65 * self.y_velocity  # Bounce
            new_y_pos = target_y + dist_to_go  # Move back above floor

        self.posn = (x, new_y_pos)  # Set our new position.

    # Create a draw method that would draw the sprites on the screen
    # Here, we invoke the blit method inside a class method (draw) to perform
    # desired operation - draw to screen on OBC (Object Being Created)
    def draw(self, vg_screen):
        #vg_screen.blit(self.image, self.fnl_positn)
        vg_screen.blit(self.image, self.posn)           #C

# Instantiate queens. i.e. Call the init method. position of each
# queen can be individually assigned or we can just use for loop to do this for all
#we use for loop
all_queens = []
for x, y in enumerate(permutation):
    sprite_queen = QueenSprite(queen_SO, (x*80+25, y*80+10))
    all_queens.append(sprite_queen)

# NOW ENTER GAME LOOP
# Poll and handle
while True:
    event = pygame.event.poll()
    if event.type == pygame.QUIT:
        break

    # Update
    for sprite_queen in all_queens:
        sprite_queen.update_sprite()

    # Drawings
    # First a blank chessboard
    for i in range(no_of_sq):
        col_alternator  = i % 2
        for j in range(no_of_sq):
            bd_sq = (x_coord, y_coord, sq_sz, sq_sz)
            vg_screen.fill(colours[col_alternator], bd_sq)
            col_alternator = (col_alternator+1) % 2
            y_coord += 80
        y_coord = 0
        x_coord += 80

    # Now, blit sprite to the chessboard. i.e. ask every sprite to draw itself
    for sprite_queen in all_queens:
        sprite_queen.draw(vg_screen)

    # DISPLAY
    pygame.display.flip()

pygame.quit()












