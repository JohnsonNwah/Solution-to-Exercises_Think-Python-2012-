# CHAPTER 4

#1. ..Write a void (non-fruitful) function to draw a square. Use it in a program to draw the
#   image shown below. Assume each side is 20 units. (Hint: notice that the turtle has
#   already moved away from the ending point of the last square when the program ends.)
#Soln
#There are diff. ways to tackle this problem viz
#(a) Write a function to draw a square with colour and create diff turtles thereafter
# outside the functn to move and draw OR
#(b) Define a fn to draw a sq and include size of sq, size of pen, color and movt of
# .. pen as its parameters. We'll choose this!!!

import turtle

#define a function for the playscreen
def window_screen(t, c):
    """ A function to create turtle playground, titled t and with color c"""
    ws = turtle.Screen()
    ws.bgcolor(c)
    ws.title(t)
    return ws


# Now, create a function for the square. (The idea used here is MOVE & DRAW!!)
# i.e. the turtle moves a certain position first, then draws a sq, moves again and draw and so on!

def draw_square(ttle, sqsz, pensz, penclr):
    """ A fn to draw a sq with turtle name ttle havng size sqsz, pen size (pensz), pen colour (penclr) and
    movt from centre (penmvmt)"""
    ttle.color(penclr)
    ttle.pensize(pensz)

    for m in [0, 40, 40, 40, 40]:       #implements the MOVE part stated above
        ttle.penup()
        ttle.forward(m)
        ttle.pendown()
        for i in range(4):              #Implements the square drawing part
            ttle.forward(sqsz)
            ttle.left(90)


# Now, create the window screen by calling the window_screen function
window_screen("Johnson's turtle playground", "lightgreen")

#Now, create the 5 squares from the same turtle pen, by calling the draw_square fn
jman = turtle.Turtle()
draw_square(jman, 20, 3, "deep pink")

#Now, move the turtle pen forward again, WITHOUT drawing any square, as shown in qstn
jman.penup()
jman.forward(40)
jman.pendown()




#QUESTION 2
#Write a program to draw this. Assume the innermost square is 20 units per side, and each
#successive square is 20 units bigger, per side, than the one inside it.
#SOLN
# Consider the diagram. How do you think the figure as a whole as come to be?
# There are 5 squares and then cursor jumped to next point.
#We can say this about how this figure came to be
#1. First, a square (smallest one) is drawn and cursor returns to origin
#2. Secondly, cursor then moves 225degrees from origin to next point and also 135 degree so as to face forward again.
#3. Steps 1 and 2 are then repeated again; this time though step 1 is varied slightly by size increase. step2 is repeated exactly same way!
#So, there we have our patterns and repetition
#So, to tackle this, I need to use MOVE, DRAW repetition, but with Size increasing by 20 after each movt!


#Now let's get a code that can do the following;
# (1)Perform a very similar ACTION, 5 times REPEATEDLY. Now, what is this action?
# This ACTION is "draw a square AND move by 225 degrees".
#(2) There are 2 legs to the action; SQUARE DRAWING and MOVING PEN TO NEXT POINT
# SQUARE DRAWING- Repeated 5 times, but with a slight variation viz each time the square size is increased by 20units
#So, we have to factor this in our code
# PEN MOVT TO NEXT POINT: This action is repeated EXACTLY SAME way 5 times. So, same code would do for all 5 repetitions.


def draw_square2(ttle, pensz, penclr):
    """ A fn to draw a sq with turtle name ttle havng size sqsz, pen size (pensz), pen colour (penclr) and
    movt from centre (penmvmt)"""
    ttle.color(penclr)              # these 2 lines set the pen colour ans size
    ttle.pensize(pensz)

    for m in [20, 40, 60, 80, 100]:     #this for stmt does 2 things: Gives us 5 repetitions and size increase for each

        for i in range(4):              #this is for the square drawing. at each iteration, size is changed
            ttle.forward(m)
            ttle.left(90)

        ttle.penup()                #Next 5 lines of code are for the pen movt.
        ttle.left(225)
        ttle.forward(15)
        ttle.left(135)
        ttle.pendown()



#Now, create the 5 squares from the same turtle pen, by calling the draw_square fn
jman2 = turtle.Turtle()
draw_square2(jman2, 3, "deep pink")



#3. Write a void function draw_poly(t, n, sz) which makes a turtle draw a regular
# polygon. When called with draw_poly(tess, 8, 50), it will draw a shape like this:

#SOlution
# Polygon has 8 sides and angle between them is 360/8 = 45.
#So, I just draw a shape with length 50, angle 45, repeated 8 times!

def draw_poly(t, n, sz):
    """ A polygon t, with no of isdes n and length of sides 50."""

    t.color("deep pink")
    t.pensize(3)

    for i in range(n):
        t.forward(sz)
        t.left(45)

t = turtle.Turtle()
draw_poly(t, 8, 50)




