
from ch15_Exercises_CLASSES_OBJECTS import Point


#   1.
'''
    Add a method area to the Rectangle class that returns the area of any instance:
    r = Rectangle(Point(0, 0), 10, 5)
    test(r.area() == 50)


#   2.
    Write a perimeter method in the Rectangle class so that we can find the
    perimeter of any rectangle instance:
            r = Rectangle(Point(0, 0), 10, 5)
            test(r.perimeter() == 30)


#   3.
    Write a flip method in the Rectangle class that swaps the width and the
    height of any rectangle instance:
            r = Rectangle(Point(100, 50), 10, 5)
            test(r.width == 10 and r.height == 5)
            r.flip()
            test(r.width == 5 and r.height == 10)



#   4.
    Write a new method in the Rectangle class to test if a Point falls within
    the rectangle. For this exercise, assume that a rectangle at (0,0) with
    width 10 and height 5 has open upper bounds on the width and height, i.e.
    it stretches in the x direction from [0 to 10), where 0 is included but 10
    is excluded, and from [0 to 5) in the y direction. So it does not contain
    the point (10, 2). These tests should pass:

            r = Rectangle(Point(0, 0), 10, 5)
            test(r.contains(Point(0, 0)))
            test(r.contains(Point(3, 3)))
            test(not r.contains(Point(3, 7)))
            test(not r.contains(Point(3, 5)))
            test(r.contains(Point(3, 4.99999)))
            test(not r.contains(Point(-3, -3)))
#SOLN to This Question
    1) A list was used to represent stretch in each direction viz:
        x-directn-stretch = list (range(0, 10)) AND
        y-directn-stretch = list (range(0, 5))
            (the range takes care of the open bound requirement)
    2) Now, each coordinate of the target point was respectively checked inside
    their respective lists. target_pt.x was checked in x-list and ditto
    for y. "in" and "AND" were used.




#   5.
    In games, we often put a rectangular “bounding box” around our sprites.
    (A sprite is an object that can move about in the game, as we will see
    shortly.) We can then do collision detection between, say, bombs and
    spaceships, by comparing whether their rectangles overlap anywhere.

    Write a function to determine whether two rectangles collide.
    Hint: this might be quite a tough exercise! Think carefully about all the
    cases before you code.
#MY SOLUTION:
    1) This example requires that our corners be randomly generated instead of
        the static assignment of values being done. hence, at each call, we can
        check if they collide, that is, if any of their parts touch each other or
        more specifically, if their stretch in either or both of x and y direction
        touch.

'''

class Rectangle:
    """ Class to create rectangles"""

    #create and initialize
    def __init__(self, position, width, height):
        """ Creates a rectangle at corner (position), having width and height"""
        self.position = position
        self.width = width
        self.height = height

    #convert instance to string
    def __str__(self):
        return "{0}, {1}, {2}".format(self.position, self.width, self.height)

    #method to update its attributes
    def change_sz(self, width_upd, height_upd):
        """ Method to update size, i.e. width and height"""
        self.width = self.width + width_upd
        self.height = self.height + height_upd

    #method to update position (which is a Point object itself)
    def change_pos(self, dx, dy):
        """ Method updates position in x and y directions by dx and dy"""
        self.position.x = self.position.x + dx
        self.position.y = self.position.y + dy

    #Answer to question 1
    def area(self):
        """ Method retruns the area of the rectangle, i.e. width * height"""
        return self.width * self.height

    #Answer to question 2
    def perimter(self):
        """ Method to return perimter of the rectangle i.e 2 *(w + h)"""
        return 2 * (self.width + self.height)

    #Answer to question 3
    def flip(self):
        """Method swaps the width to height and vice-versa. A copy of each size
        was first made, using the copy function and then assigned to respective
        pair"""
        import copy
        self.width2 = copy.copy(self.height)
        self.height2 = copy.copy(self.width)
        self.width = self.width2
        self.height = self.height2
        return self.width, self.height


    #Answer to question 4
    def contains(self, target_point):
        """ Method checks if a point falls inside the rectangle"""
        x_dir_stretch = list(range(0, 10))      #captures stretch in x-directn
        y_dir_stretch = list(range(0, 5))       #captures stretch in y-directn
        return (target_point.x in x_dir_stretch and
                        target_point.y in y_dir_stretch)

    #Answer to question 5
    def collide(self, target_rect):
        """ Method to check if two rectangles, which contain sprites collide"""
        from random import randrange
        self.position.x = randrange(0, 10)
        self.position.y = randrange(0, 5)
        target_rect.position.x = randrange(0, 10)
        target_rect.position.y = randrange(0, 5)
        dist_x = abs(self.position.x - target_rect.position.x)
        dist_y = abs(self.position.y - target_rect.position.y)

        return "Check is {0}, dist_x is {1}, dist_y is {2}, bomb x-pos is {3} \
                bomb y-pos is {4}, spaceship x-pos is {5}, spaceship y-pos is \
                {6}". format \
                (dist_x <= self.position.x and dist_y <= self.position.y, \
                dist_x, dist_y, self.position.x, self.position.y, \
                target_rect.position.x, target_rect.position.y)


bomb = Rectangle(Point(8, 10), 4, 3)
spaceship = Rectangle(Point(10, 6), 4, 3)
print(bomb)
print(spaceship)
print(bomb.collide(spaceship))








'''
r = Rectangle(Point(0, 0), 10, 5)
#print(r.width);
#print(r.height)
#r.flip()
#print(r.width);
#print(r.height)
print(not r.contains(Point(-3, -3)))

'''