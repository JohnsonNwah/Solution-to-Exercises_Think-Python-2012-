
import random
import time


#   1.
'''
The section in this chapter called Alice in Wonderland, again! started with the
observation that the merge algorithm uses a pattern that can be reused in other
situations. Adapt the merge algorithm to write each of these functions, as was suggested there:

    (a) Return only those items that are present in both lists.
    (b) Return only those items that are present in the first list, but not in the second.
    (c) Return only those items that are present in the second list, but not in the first.
    (d) Return items that are present in either the first or the second list.
    (e) Return items from the first list that are not eliminated by a matching element
        in the second list. In this case, an item in the second list â€œknocks outâ€ just
        one matching item in the first list. This operation is sometimes called bagdiff.
        For example bagdiff([5,7,11,11,11,12,13], [7,8,11]) would return
        [5,11,11,12,13]'''

#   SOLUTIONS


#   1A.   PICK ONLY ITEM THAT ARE PRESENT IN BOTH LISTS
# Similar to above too. only this time, we feed result list ONLY with items
#   having same values. i.e. when lista[countera] == listb[counterb]
#outside of this, we only move to next item
def present_in_both_list(list_a, list_b):
    """ Fn to check through two lists and return ONLY item unique to both list,
    into a new result list"""

    #sort and remove duplicates:    ALREADY DONE
    #Declare IVA TV
    result_list = []
    counter_a = 0
    counter_b = 0

    #implement exit and comparison codes
    while True:
            #exit code
        if counter_a >= len(list_a):        #if list a is fully transversed, then
            return result_list              #can't find similar items again.so just exit code

        if counter_b >= len(list_b):        #same as above
            return result_list

            #comparison operation
        if list_a[counter_a] < list_b[counter_b]:       #if lista item is less than list be item
            counter_a += 1                              #then, move to next list a item

        elif list_a[counter_a] == list_b[counter_b]:    #when both are same, pick list a's item and
            result_list.append(list_a[counter_a])       # increment its counter. (we could have picked
            counter_a += 1                              #b also and incremented it's counter.)
            counter_b += 1
        else:
            counter_b += 1

#test
items_only_in_both = present_in_both_list(a, b)
print(items_only_in_both)







#   1B.     RETURN ONLY ITEM UNIQUE TO A
# Just adjust, what you feed to result list viz:
# Feed result list, WITH lesser value items that occur ONLY in a
def unique_to_a(list_a, list_b):
    """ Function to check lists a and b, and return only items unique to a"""

    # sort and remove duplicates: done for both, no duplicate

    #declare IVA TV
    result_list = []
    counter_a = 0
    counter_b = 0

    #Inside loop, implement exit mech and comparison
    #exit mechanism
    while True:
        if counter_a >= len(list_a):        #if list a is fully transvered, exit program
            return result_list

        if counter_b >= len(list_b):        #if list b is fully transvered, add remaining
            result_list.extend(list_a[counter_a])       #items in list a to result list and
            return result_list                          #exit program

        #comparison
        if list_a[counter_a] < list_b[counter_b]:       #if list a element is the lesser-value one,
            result_list.append(list_a[counter_a])           #add it to result list and
            counter_a += 1                              #move to next element of this list

        elif list_a[counter_a] == list_b[counter_b]:    #if list a element has same value as list b's,
            counter_a += 1                              #Ignore this list a element and move to next one
        else:
            counter_b += 1                              # if list b element is the lesser one, ignore this
                                                        #element and move to next list be element
#test
#unique_list_a = unique_to_a(a, b)
#print(unique_list_a)






#   1C.     RETURN ONLY ITEM UNIQUE TO B
#Repeat same thing done in "unique to a" functn, only this time, feed b's lesser-value item to result list
def unique_to_b(list_a, list_b):
    """ Function to check lists a and b, and return only items unique to a"""

    # sort and remove duplicates: done for both, no duplicate

    #declare IVA TV
    result_list = []
    counter_a = 0
    counter_b = 0

    #Inside loop, implement exit mech and comparison
    #exit mechanism
    while True:
        if counter_b >= len(list_b):        #if list b is fully transvered, exit program
            return result_list

        if counter_a >= len(list_a):       #if list a is fully transvered, add remaining
            result_list.extend(list_b[counter_b:])       #items in list b to result list and
            return result_list                          #exit program

        #comparison
        if list_b[counter_b] < list_a[counter_a]:       #if list b element is the lesser-value one,
            result_list.append(list_b[counter_b])           #add it to result list and
            counter_b += 1                              #move to next element of this list

        elif list_b[counter_b] == list_a[counter_a]:    #if list b element has same value as list a's,
            counter_b += 1                              #Ignore this list b element and move to next one
        else:
            counter_a += 1                              # if list a element is the lesser one, ignore this
                                                        #element and move to next list be element
#test
unique_list_b = unique_to_b(a, b)
print(unique_list_b)







#   1D. FUNCTION TO RETURN ITEMS IN EITHER LIST, INTO THE RESULT LIST
#Very similar to our code above that returns item unique to both. just this time, we use a single list
#to collect our results
def items_in_either(list_a, list_b):
    """ Fn to compare two list, a and b, adnd return items in either, to a result list"""

    #Declare IVA TV
    result_list = []
    counter_a = 0
    counter_b = 0
    counter = 0

     #implement exit and comparison codes
    while True:
            #exit codef
        if counter_a >= len(list_a):
            result_list.extend(list_b[counter_b:])
            counter += 1
            return result_list, counter

        if counter_b >= len(list_b):
            result_list.extend(list_a[counter_a:])
            counter += 1
            return result_list, counter

            #comparison operation
        if list_a[counter_a] < list_b[counter_b]:
            result_list.append(list_a[counter_a])
            counter_a += 1
        elif list_a[counter_a] == list_b[counter_b]:    #once the two items in la and lb are same
            counter_a += 1                              #move to next items in each list
            counter_b += 1
        else:
            result_list.append(list_b[counter_b])
            counter_b += 1
        counter += 1


#test
#items_occur_in_either = items_in_either(a, b)
#print(items_occur_in_either)



#ADDITIONAL CODES BY ME 1F TO 1I

#   1F. FUNCTION TO MERGE THEM ANY DUPLICATE

def merge_sorted_lists(x_list, y_list):
    """ A function to merge two sorted lists, without any duplicate"""

    #Sort list:
    x_list.sort()
    y_list.sort()

    #Declare IVA TV
    result_list = []
    counter_x = 0
    counter_y = 0

    #Implemenet exit code and comparisons
    #exit code
    while True:
        if counter_x >= len(x_list):
            result_list.extend(y_list[counter_y:])
            return result_list
        elif counter_y >= len(y_list):
            result_list.extend(x_list[counter_x:])
            return result_list

        #implement comparisons
        if x_list[counter_x] <= y_list[counter_y]:
            result_list.append(x_list[counter_x])
            counter_x += 1
        else:
            result_list.append(y_list[counter_y])
            counter_y += 1

#test
merged_list = merge_sorted_lists(a, b)
print(merged_list)




#   1G.     REMOVE DUPLICATES FOR FROM C ABOVE
def duplicate_remover(list_with_duplicate):
    """ A fn to remove duplicate from lists"""

    #sort list (to make duplicates adjacent to each other/one another)
    list_with_duplicate.sort()

    #Declare IVA TV
    result_list = []
    mrai = None

    #implement appending and Update, as you transverse the list elements
    for x in list_with_duplicate:
        if x != mrai:
            result_list.append(x)
            mrai = x            #Most vital part; it remembers recently added item
    return result_list

#test
merged_list_no_duplicate = duplicate_remover(merged_list)
print(merged_list_no_duplicate)




#   1H. FUNCTION TO MERGE LISTS, WITHOUT DUPLICATING ITEMS
def merge_sorted_lists(x_list, y_list):
    """ A function to merge two sorted lists, without any duplicate"""

    #Sort list:
    x_list.sort()
    y_list.sort()

    #Declare IVA TV
    result_list = []
    counter_x = 0
    counter_y = 0

    #Implemenet exit code and comparisons
    #exit code
    while True:
        if counter_x >= len(x_list):
            result_list.extend(y_list[counter_y:])
            return result_list
        elif counter_y >= len(y_list):
            result_list.extend(x_list[counter_x:])
            return result_list

        #implement comparisons
        if x_list[counter_x] < y_list[counter_y]:
            result_list.append(x_list[counter_x])
            counter_x += 1
        elif x_list[counter_x] == y_list[counter_y]:
            result_list.append(x_list[counter_x])
            counter_x += 1
            counter_y += 1
        else:
            result_list.append(y_list[counter_y])
            counter_y += 1

#test
merged_list = merge_sorted_lists(a, b)
print(merged_list)



#   1I.     WHAT ABOUT A CODE THAT RETURNS TWO LISTS, CONTAINING ITEM UNIQUE TO BOTH LISTS?
#We'll be using two result lits now and carefully craft our code
def unique_to_each_list(list_a, list_b):
    """ Fn to check through two lists and return item unique to each list, into
    two diferent result lists, one for each list"""

    #sort and remove duplicates:    ALREADY DONE
    #Declare IVA TV
    result_list_a = []
    result_list_b = []
    counter_a = 0
    counter_b = 0

    #implement exit and comparison codes
    while True:
            #exit code
        if counter_a >= len(list_a):
            result_list_b.extend(list_b[counter_b:])
            return result_list_a, result_list_b

        if counter_b >= len(list_b):
            result_list_a.extend(list_a[counter_a])
            return result_list_a, result_list_b

            #comparison operation
        if list_a[counter_a] < list_b[counter_b]:
            result_list_a.append(list_a[counter_a])
            counter_a += 1

        elif list_a[counter_a] == list_b[counter_b]:
            counter_a += 1
            counter_b += 1
        else:
            result_list_b.append(list_b[counter_b])
            counter_b += 1

#test
unique_each_list = unique_to_each_list(a, b)
print(unique_each_list)












#   QUESTION 2.
#   Modify the queens program to solve some boards of size 4, 12, and 16.
#   What is the maximum size puzzle you can usually solve in under a minute?
#SOLNS

#   BOARD OF SIZE 4
'''
size 4 means N = 4. SO, JUST CHANGE UR LIST TO PROUCE 4 ITEMS
    ( since any solution to the queen puzzle, must be a permutation of numbers (0 .. N-1),
    hence, our permutation would be a list of length 4, starting from 0;
    e.g. [0, 1, 3, 4]
so, in this case, we make bs = list of length 4, starting from 0.

 CODE BECOMES..'''


#Fn 1, to check, if two queens share diagonal
def share_diagonal(x0, y0, x1, y1):
    """ Fn to check if two queens share diagonal, using their x,y coordinate
    location. Queens share diagonal, if "Distance between them, IS the same in
    x, y direction. Function returns True is they share diagonal"""

    dist_in_x = abs(x1 - x0)
    dist_in_y = abs(y1 - y0)

    #return dist_in_x == dist_in_y
    if dist_in_x == dist_in_y:
        return True
    return False

#FN 2: check each queen, against each individual queen in precedding column
# Idea here is to start checking every subsequent queen we place, AFTER THE
#   FIRST ONE (which of course doesn't clash with any queen), to see if that
#   new queen shares diagonal with ANY of the queens before it.
def test_this_queen_plcmt(permutation, queen_col_pos):
    """ Fn to check given queen in given column position, if it clashes against
    queens preceeding it in the permutation"""

    #Note: for the for loop below:  i = x coordinate of preceeding queen,
            #permutation[i] = preceeding queen position in permutation list i.e.
            # it's actual position on y-axes

    for i in range((queen_col_pos)):
        if share_diagonal(i, permutation[i], queen_col_pos, permutation[queen_col_pos]) == True:
            return True         #i.e. the queen being checked, clashes with precedding queen at given column i
    return False              # i.e. the queen being checked does not clash with this queen at column i


#Fn 3:  Now, Test generated permutation, if it is a solution to the puzzle i.e.
        #Here, PERMUTATION IS A SOLUTION, FUNCTION RETURNS FALSE
def test_all_column_plcmts(permutation):
    """ Function to test given permutation if it is a a solution
    Fn tests, a queen at each column, sartimg from column o, and tests this queen
    aganst all other queens in other columns. That way we know all clumn entries
    are valid"""

    for given_column in permutation:
        if test_this_queen_plcmt(permutation, given_column) == True:
            return True
    return False            #All column placements are ok


#fn 4: generating permutations
def test_permutation():
    """ Fn to generate and test various permutations to see if they are solution."""
    import time
    import random
    rg = random.Random()
    permutation = list(range(0, 16))     #first permutation to be tested
    #permutation = [4, 7, 3, 0, 6, 1, 5, 2]
    counter_attempts = 0                #counts how many iteration is done(attempts), b4 a valid permutation is found
    result_counter = 1                  #counter is incremented, ONLY IF permutation is a solution

    while result_counter <= 10:         #we need  10 solutions. continue testing until no of solution is 10
        counter_attempts += 1
        t1 = time.clock()
        if (test_all_column_plcmts(permutation)) == False:
            t2 = time.clock()
            time_elapsed = t2 - t1
            print("Valid Permutation no {0}, ran for {1} seconds, took {2} attempts and is {3}".format
                    (result_counter, time_elapsed, counter_attempts, permutation))
            result_counter += 1
            counter_attempts = 0        # this initializes the counter, after a solution is found, else it would count progressively
            #t1 = 0.0
        #rg.shuffle(permutation)         #starting from first solution
        permutation = rg.sample(permutation, 16)

#test exercise 1
test_permutation()






#   QUESTION 3.
'''
Adapt the queens program so that we keep a list of solutions that have already printed,
so that we don’t print the same solution more than once.'''
#SOLUTION
'''
    This would use the "removing adjacent duplicate sort of principle": Remembering most recent items
    STEPS ARE:
    1) REMEMBER THE MOST RECENTLY VERIFIRED SOLUTION (i.e. the most recent permutation that is a solutn to the puzzle)
    2) TEST FOR SIMILARITY BETWEEN THE ABOVE MRVS AND EITHER:
        A) THE NEXT GENERATED PERMUTATION (BEFORE TESTING)
        B) THE NEXT VERIFIED PERMUTATIUON (AFTER TESTING)
    So, we either compare   "after generation and before validation, of the permutation" or
                            "after generation and verification, of the new permutation"

3A) COMPARE AFTER GENERATION AND BEFORE TESTING '''
def get_unique_permutation():
    """ Fn to get solution to the puzzle, that are unique"""

    import random
    rh = random.Random()
    permutations = list(range(0, 8))
    result_counter = 0
    attempts_counter = 0
    no_of_solutions_reqd = 10
    result_list = []

    while result_counter < no_of_solutions_reqd:
        attempts_counter += 1
        if has_clashes(permutations) == True:
            pass
        else:
            result_list.append(permutations)
            result_counter += 1
            attempts_counter = 0
        permutations = rh.sample(permutations, len(permutations))
    return result_list















