# CHAPTER 7: ITERATIONS

# 1. Write a function to count how many odd numbers are in a list.
#SOLN

#Anything count, you need a counter!.
#Also, best branching statement to use here would be a 'continue' statement

def count_odd(the_list):
    """A fnto count how many odd numbers in a list"""
    counter = 0
    for a in the_list:
        if a % 2 == 0:      #if number is even, forget remaining loop body and
            continue        #go back to loop header for next iteration!
        counter += 1
    print('Number of odd numbers in this list is', counter)

x = range(1, 21)
test_count_odd = count_odd(range(1, 30))



#2. Sum up all the even numbers in a list.
#SOLN
#We can use this same continue statement
def sum_even(the_list):
    """A fn to sum the even nos in a list"""
    x = 0
    for a in the_list:
        if a % 2 != 0:      #if number is odd, forget remaining loop body and
            continue        #go back to loop header for next iteration!
        x += a
    print('Sum of even numbers in this list is', x)

x = range(1, 21)
test_sum_even = sum_even(x)


# 3. Sum up all the negative numbers in a list.
#SOLN
#We can use continue, return, break or pass statements here too.
#we are gonna use continue statements
def sum_negative(the_list):
    """A fn to sum the negative nos in a list"""
    x = 0
    for a in the_list:
        if a >= 0:      #if number is greater than 0, forget remaining loop body and
            continue        #go back to loop header for next iteration!
        x += a
    print('Sum of all negative numbers in this list is', x)

x = range(-10, 11)
test_sum_negative = sum_negative(x)



# 4. Count how many words in a list have length 5.
#SOLN
#As ususal, a counter needs a counter .. lol
def count_words(the_list):
    """A fn to count how many words in a list have length 5"""
    counter = 0
    for a in the_list:
        if len(a) != 5:      #if number is even, forget remaining loop body and
            continue        #go back to loop header for next iteration!
        counter += 1
    print('Number of words with length 5 is ', counter)

x = ["apple", 'orange', 'These', 'are', 'sweet', 'fruits', 'yelso']
test_count_words = count_words(x)



# 5. Sum all the elements in a list up to but not including the first even number. (Write your
# unit tests. What if there is no even number?)
# SOLN
# This is where you use break: exit a list, UPON hitting a condition!

def sum_odds(the_list):
    """ A fn to sum all items in a list, up to but not including the 1st even number"""
    x = 0
    for a in the_list:
        if a % 2 == 0:
            break
        x += a
    print('Sum of items, up to and excluding the first even number is', x)


test_sum_odds = sum_odds([1, 3, 5, 11, 12, 15, 25, 26, 30])



# 6. Count how many words occur in a list up to and including the first occurrence of the word
#â€œsamâ€. (Write your unit tests for this case too. What if â€œsamâ€ does not occur?)
#As usual, this is a case of "exit a loop, UPON hitting a condition!", So, break statment to the rescue!!!
def count_words_sam(the_list):
    """ A fn to Count how many words occur in a list up to and including the
    first occurrence of the word "sam". """
    counter = 0
    for a in the_list:
        counter += 1
        if a == "sam":
            break
    print('Count of words up to and including 1st "sam" occurence is', counter)

count_words_sam(['Elyse', 'no', 'more', 'questions', 'about', 'sam', 'for', 'now'])



# 7. Add a print function to Newtonâ€™s sqrt function that prints out better each time it is
# calculated. Call your modified function with 25 as an argument and record the results.



# 9. Write a function print_triangular_numbers(n) that prints out the first n triangular
# numbers. A call to print_triangular_numbers(5) would produce the
# following output:
#       1 1
#       2 3
#       3 6
#       4 10
#       5 15
#(hint: use a web search to find out what a triangular number is.)
#SOLN
#A triangular number incrementally increases natural number by preceding results
#1, 3, 6, 10, 15, 21 etc

#Looking at result above, a pattern is discovered viz
#The print function contains 2 arguments. (so, 2 outputs are printed during each call ON SAME LINE, BUT DIFFERENT COLUMNS!
#first argument above, is an increment (addition of 1), of the natural number: 1    2   3   4   5 etc
#second argument is the triangular number, in order too.
#So, we need two arguments to the function and we use SUCCESIVE MODIFICATION LOOP to get the job done.
#Recal, this is a LOOP, THAT SUCCEIVELY CHANGES A VARIABLE'S VALUE, DURING EACH ITERATION.
#Usually, for use in that or next iteration.

def triangular_numbers(n):
    """A Fn that prints ou first n triangular numbers as seen above"""
    x = 1
    y = 1
    for i in range(n):  #we are setting up no of times output is printed i.e. n times
        print(x, y)
        x = x + 1       #increments x by 1 for use in next iteration
        y = y + x         #updates y to produce triangular number progression


triangular_numbers(10)


# 10. Write a function, is_prime, which takes a single integer argument and returns True
# when the argument is a prime number and False otherwise. Add tests for cases like this:
# SOLN
def is_prime(x):
    """A fn that takes a single integar argument and returns True or False depending if
    it's prime or not"""
    #Prime no is only divisible by itself and 1
    if x == 1 or x == 2 or x == 3:
        return True
    if x % 2 == 0 or x % 3 == 0:
        return False
    else:
        return True

print(is_prime(9))





