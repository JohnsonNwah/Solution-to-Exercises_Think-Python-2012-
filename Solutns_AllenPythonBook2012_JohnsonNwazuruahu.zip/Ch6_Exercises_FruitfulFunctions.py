#           CHAPTER 6: FRUITFUL FUNCTIONS

import sys

import turtle


# 1. The four compass points can be abbreviated by single-letter strings as Ã¢â‚¬Å“NÃ¢â‚¬Â, Ã¢â‚¬Å“EÃ¢â‚¬Â, Ã¢â‚¬Å“SÃ¢â‚¬Â, and
# Ã¢â‚¬Å“WÃ¢â‚¬Â. Write a function turn_clockwise that takes one of these four compass points
#as its parameter, and returns the next compass point in the clockwise direction. Here are
#some tests that should pass:       test(turn_clockwise("N") == "E")
#                                   test(turn_clockwise("W") == "N")
#You might ask Ã¢â‚¬Å“What if the argument to the function is some other value?Ã¢â‚¬Â For all other
#cases, the function should return the value None:
#           test(turn_clockwise(42) == None)
#           test(turn_clockwise("rubbish") == None)

#SOLN

#Recall, first step is "DETERMINE, WHAT I/PS AND O/PS SHOULD BE
#Qtns says, a function that takes ONE ... . so,
# Input should be any one argument... AND... O/P shld be next point.
# Each of the 4 points would be made to refer to the argument above.

def turn_clockwise(x):
    """ A function that takes a compass point as input 'x' and returns next
    point on a compass point, in a clockwise movmt. any other point is returned
    as None"""
    if x == "N":
        return "E"
    elif x == "E":
        return "S"
    elif x == "S":
        return "W"
    elif x == "W":
        return "N"
    else:
        return

c = turn_clockwise("E")
print( "Result of c is", c)



# 2. Write a function day_name that converts an integer number 0 to 6 into the name of a
# day. Assume day 0 is Ã¢â‚¬Å“SundayÃ¢â‚¬Â. Once again, return None if the arguments to the function
# are not valid. Here are some tests that should pass:
#    test(day_name(3) == "Wednesday")
#   test(day_name(6) == "Saturday")
#   test(day_name(42) == None)

#SOLN
#Write the function

def day_name(x):
    """ A fn, that accepts '0' to '6' as day names and converts them appropriately
    to day names, starting from sunday"""
    if x == 0:
        return ("Sunday")
    elif x == 1:
        return ("Monday")
    elif x == 2:
        return ("Tuesday")
    elif x == 3:
        return ("Wednesday")
    elif x == 4:
        return ("Thursday")
    elif x == 5:
        return ("Friday")
    elif x == 6:
        return ("Saturday")
    return



#3. Write the inverse function day_num which is given a day name, and returns its number:
#   test(day_num("Friday") == 5);       test(day_num("Sunday") == 0)
#test(day_num(day_name(3)) == 3)        test(day_name(day_num("Thursday")) == "Thursday")
# Once again, if this function is given an invalid argument, it should return None:
#   test(day_num("Halloween") == None)

#SOLN

def day_num(x):
    """ A fn, that accepts 'Sunday' to 'Saturday' as day names and converts them
    appropriately to day numbers, starting from 0"""
    if x == "Sunday":
        print("Day number for", x, "is 0")
        return 0
    elif x == "Monday":
        return 1
    elif x == "Tuesday":
        return 2
    elif x == "Wednesday":
        return 3
    elif x == "Thursday":
        return 4
    elif x == "Friday":
        return 5
    elif x == "Saturday":
        return 6
    return


b = day_num("0")
print("Day number for your input is", b)



# 4. Write a function that helps answer questions like Ã¢â‚¬Å“Ã¢â‚¬ËœToday is Wednesday. I leave on
# holiday in 19 days time. What day will that be?Ã¢â‚¬ÂÃ¢â‚¬â„¢ So the function must take a day name
# and a delta argument Ã¢â‚¬â€ the number of days to add Ã¢â‚¬â€ and should return the resulting day name:
#   test(day_add("Monday", 4) == "Friday");     test(day_add("Tuesday", 0) == "Tuesday")
#   test(day_add("Tuesday", 14) == "Tuesday");  test(day_add("Sunday", 100) == "Tuesday")
#SOLN
#Determine i/p and o/p; I/Ps= day name and days to add ..AND..; O/P Resulting day name
#I have chosen to use earlier used functns that convert days in a week to numbers AND
# numbers 0 - 6 to days in a week.

#Program flow is :
#1) Get today's day and change it to a number between 0 and 6(using functn above (day_num). Call this no say, x.
#2) Now, add this x to the no of days in which you wanna leave(say y). i.e. x + y (call the reult z)
#3. Now, divide z by no of days in a week and call the remainder 'a'
# Now, convert this number a, to a day of the week, using already defined fn again.(day_name)

def day_add(present_day, days_to_go):
    """ Fn to tell what DAY it is when you wanna go for vacation. you supply two
    inputs viz; present day = what DAY it is today ... AND
                days_to_go i.e. in how many days time you wanna go"""

    x = day_num(present_day)
    days_in_a_week = 7
    actual_day_to_travel_in_no = (x + (days_to_go)) % days_in_a_week
    actual_day_to_travel_in_day = day_name(actual_day_to_travel_in_no)
    return actual_day_to_travel_in_day

q = day_add("Sunday", 100)
print("You are to travel on", q)




# 5. Can your day_add function already work with negative deltas? For example, -1 would
#be yesterday, or -7 would be a week ago:
#   test(day_add("Sunday", -1) == "Saturday");      test(day_add("Sunday", -7) == "Sunday")
#   test(day_add("Tuesday", -100) == "Sunday");
# If your function already works, explain why. If it does not work, make it work.
# Hint: Play with some cases of using the modulus function % (introduced at the beginning
# of the previous chapter). Specifically, explore what happens to x % 7 when x is
# negative.

#SOLN
#Yes, my function works with negative numbers because, of the rules of precendence.

v = day_add("Tuesday", -100)
print("You are to now travel on", v)




# 6. Write a function days_in_month which takes the name of a month, and returns the
# number of days in the month. Ignore leap years:
#   test(days_in_month("February") == 28);      test(days_in_month("December") == 31)
#   If the function is given invalid arguments, it should return None.
#SOLN
#Function input = name of a month. A string
#Function o/p = no of days in the month. an integar.
# We can use OR here, since several months have same no of days

def days_in_month(x):
    """A fn that inputs month name and o/ps no of days in it"""
    a = 28;         b = 30;         c = 31
    if x == "Janauary" or x =="March" or x == "May" or x == "July":
        return c
    elif x == "August" or x == "October" or x =="December":
        return c
    elif x =="September" or x == "April" or x =="June" or x == "November":
        return b
    elif x == "February":
        return a
    else:
        return

#test_month_days = days_in_month("come")
#print("No of days in given month is", test_month_days)





# 7. Write a function to_secs that converts hours, minutes and seconds to a total number
# of seconds. Here are some tests that should pass:
# test(to_secs(2, 30, 10) == 9010);         test(to_secs(2, 0, 0) == 7200)
# test(to_secs(0, 2, 0) == 120);            test(to_secs(0, 0, 42) == 42)
# test(to_secs(0, -10, 10) == -590)
#SOLN
#Functn details; I/ps = 3 arguments viz h,m,s  AND O/p = total seconds
def to_secs(h, m, s):
    """ A fn that inputs hours 'h', minutes 'm' and seconds 's' and gives
    total number of seconds 'total secs'"""
    hours_to_sec = h * 60 * 60
    minutes_to_sec = m * 60
    total_secs = hours_to_sec + minutes_to_sec + s
    return total_secs

#test_to_sec = to_secs(2, 30, 10)
#print("Total seconds is", test_to_sec)




# 8. Extend to_secs so that it can cope with real values as inputs. It should always return
# an integer number of seconds (truncated towards zero):
#   test(to_secs(2.5, 0, 10.71) == 9010);       test(to_secs(2.433,0,0) == 8758)















#   NOW, LET'S RUN OUR TESTS!
#Helper Fn
def test(did_pass):
    """ Fn to chech test result; i.e. a helper function"""
    linenumber = sys._getframe(1).f_lineno
    if did_pass:
        msg = "Test at line {0} ok".format(linenumber)
    else:
        msg = "test at line {0} FAILED". format(linenumber)
    print(msg)

#Test suites
def test_suite():
    """ Run the suite of tests for code in this module (this file) """
    test(turn_clockwise("N") == "E")            #Next 4 lines are tests for  Exercise1
    test(turn_clockwise("W") == "N")
    test(turn_clockwise("N") == None)
    test(turn_clockwise("rubbish") == None)
    test(day_name(3) == "Wednesday")            #Next 3 lines are tests for Exercise2
    test(day_name(7) == "Saturday")
    test(day_name(42) == None)
    test(day_num("Friday") == 5)                #Next 5 lines are tests for Exercise3
    test(day_num("Sunday") == 0)
    test(day_num(day_name(3)) == 3)
    test(day_name(day_num("Thursday")) == "Thursday")
    test(day_num("Halloween") == None)
    test(day_add("Monday", 4) == "Friday")      #Next 4 lines are tests for Exercise4
    test(day_add("Tuesday", 0) == "Tuesday")
    test(day_add("Tuesday", 14) == "Tuesday")
    test(day_add("Sunday", 100) == "Tuesday")
    test(day_add("Sunday", -1) == "Saturday")   #Next 3 lines are tests for Exercise5
    test(day_add("Sunday", -7) == "Sunday")
    test(day_add("Tuesday", -100) == "Sunday")
    test(days_in_month("February") == 28)       #Next 3 lines are tests for Exercise6
    test(days_in_month("December") == 31)
    test(days_in_month("come") == 28)
    test(to_secs(2, 30, 10) == 9010)            #Next 5 lines are tests for Exercise7
    test(to_secs(2, 0, 0) == 7200)
    test(to_secs(0, 2, 0) == 120)
    test(to_secs(0, 0, 42) == 42)
    test(to_secs(0, -10, 10) == -590)



test_suite()                    # Here is the call to run the tests