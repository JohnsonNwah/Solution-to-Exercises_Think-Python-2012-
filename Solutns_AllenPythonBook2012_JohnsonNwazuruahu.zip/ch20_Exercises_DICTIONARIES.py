

#   1.
'''
    Write a program that reads a string and returns a table of the letters of
    the alphabet in alphabetical order which occur in the string together with
    the number of times each letter occurs. Case should be ignored.
    A sample output of the program when the user enters the data
    â€œThiS is String with Upper and lower case Lettersâ€, would look this this:
        a  2
        c  1
        d  1
        e  5
        g  1
        h  2
        i  4
        l  2
        n  2
        o  1
        p  2
        r  4
        s  5
        t  5
        u  1
        w  2
'''
# SOLN
#STEPS:
'''
    a: Since case don't matter, forst turn all to lowercase
    b: create empty dictionary
    c: transverse each letter in the string (using for loop) and during each
        iteration, invoke get method on the string
        c1: if key's value exists, increment the value by 1
        c2: else, simply increment the new key by 1 still. this translates to
                    adding a new letter to the dictionary
'''



def frequency_table(input_string):
    """ Fn to prepare a frequency table for given string"""

    lowercase_str = input_string.lower()
    result_dict = dict()
    for letter in lowercase_str:
        if letter != " ":       # ignores whitespaces
            result_dict[letter] = result_dict.get(letter, 0) + 1   #add dict items

    # turn collated result to list of 2-element tuples (keys and values)
    list_result = list(result_dict.items())

    # sort it alphabetically
    list_result.sort()

    # collate each tuple-element of the list in the order:
    # tuple-element0 + 2 spaces + tuple-element1 + newline
    output = ""
    for x, y in list_result:
        result = str(x) + "  " + str(y) + "\n"
        output = output + result
        #print(x, y)
    # return final result
    return output


test = "ThiS is String with Upper and lower case Letters"
print(frequency_table(test))







#   2.
''' Give the Python interpreterâ€™s response to each of the following from a
    continuous interpreter session:
        >>> d = {"apples": 15, "bananas": 35, "grapes": 12}
        >>> d["bananas"]
        >>> d["oranges"] = 20
        >>> len(d)
        >>> "grapes" in d
        >>> d["pears"]
        >>> d.get("pears", 0)
        >>> fruits = list(d.keys())
        >>> fruits.sort()
        >>> print(fruits)
        >>> del d["apples"]
        >>> "apples" in d'''
# SOLN
#  From above
#   a.  d["bananas"] WILL GIVE 35
#
#   b.  d["oranges"] = 20   (adds an item to the dict.key = oranges, value = 20)
#       len(d) WILL GIVE 4 (after adding oranges)
#
#   c.  "grapes" in d WILL GIVE True (becuase there's a key called grapes)
#
#   d.  d["pears"] WILL GIVE Keyerror (no pears key exists, so no value for it)
#
#   e.  d.get("pears", 0) WILL GIVE 0. no pairkey exist, so specified 0 is rtrnd
#
#   f.  fruits = list(d.keys()) WILL GIVE list of all keys in the dictinary d
#                               i.e. [apples, bananas, grapes, oranges]
#       fruits.sort()       WILL GIVE a sorted list of above i.e.
#                               [apples, bananas, grapes, oranges]
#       print(fruits)       WILL SHOW sorted utput above on screen
#
#   g.  del d["apples"] WILL REMOVE apple item (apple key and associated value)
#                                   from the list
#       "apples" in d WILL GIVE False (apple has been removed)


# Be sure you understand why you get each result. Then apply what you have
# learned to fill in the body of the function below:


def add_fruit(inventory, fruit, quantity=0):
    new_inventory = {}
    new_inventory[fruit] = quantity
    return

# Make these tests work...
new_inventory = {}
add_fruit(new_inventory, "strawberries", 10)
test("strawberries" in new_inventory)
test(new_inventory["strawberries"] == 10)
add_fruit(new_inventory, "strawberries", 25)
test(new_inventory["strawberries"] == 35)







#   3.
'''
    Write a program called alice_words.py that creates a text file named
    alice_words.txt containing an alphabetical listing of all the words, and
    the number of times each occurs, in the text version of Aliceâ€™s Adventures
    in Wonderland. (You can obtain a free plain text version of the book,
    along with many others, from http://www.gutenberg.org.)
    The first 10 lines of your output file should look something
    like this:

            Word                Count
            =======================
            a                   631
            a-piece             1
            abide               1
            able                1
            about               94
            above               3
            absence             1
            absurd              2
            How many times does the word alice occur in the book?
'''
# SOLN


def words_file_generator(input_file):
    """ A Fn that reads input from a text file and returns a able showing
    frequency of occurence of each owrd in the file. Ouput is given as a
    text file in same location as input."""

    # Open and Read input file from its saved location on computer
    file_handle = open(input_file, "r")           #Open File
    read_file = file_handle.read()
    file_handle.close()                     #close the file

    # Remove punctuation
    punctuation = "Ã¯Â»Â¿!\"#$%&'()*+,./:;<=>?@[\\]^_`{|}~1234567890-"
    new_file = ""
    for letter in read_file:
        if letter not in punctuation:
            new_file += letter

    #turn to lower case
    new_file = new_file.lower()

    # Split single string into list of words
    word_list = new_file.split()

    # Transverse list and Create frequency table
    dict_word_number = dict()
    for word in word_list:
        dict_word_number[word] = dict_word_number.get(word, 0) + 1

    # Turn dictionary items to list of tuples
    list_dictionary = list(dict_word_number.items())

    #Sort list of dictionary items
    list_dictionary.sort()

    # Now write in output format
        #First, create new file
    new_file_location = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\alice_word2.txt"
    file_hd = open(new_file_location, "w")

        #Now, prepare a text layout to eb used for header and body in stg.format
        #method
    text_layout = "{0:<30} {1:<10}\n"

        #Secondly, create header and underline               # prepare table
    header = text_layout.format("Word", "Count")    #prepare the header format
    underline_header = "="*36 + "\n"                #Prepare the underline
    file_hd.write(header)                           #Write header
    file_hd.write(underline_header)                 #Underline header

        #Now, Write body of the table (words and their counts) using loop
    for key, value in list_dictionary:
        word_number = text_layout.format(key, value)
        file_hd.write(word_number)

        #close the file
    file_hd.close()

    return file_hd

#file = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\Alice adventures in Wonderland2.txt"
#words_file_generator(file)



#   4.


#SOLN

def words_length_counter(input_file):
    """ A Fn that reads input from a text file and returns a able showing
    frequency of occurence of each owrd in the file. Ouput is given as a
    text file in same location as input."""

    # Open and Read input file from its saved location on computer
    file_handle = open(input_file, "r")           #Open File
    read_file = file_handle.read()
    file_handle.close()                     #close the file

    # Remove punctuation
    punctuation = "ï»¿!\"#$%&'()*+,./:;<=>?@[\\]^_`{|}~1234567890-"
    new_file = ""
    for letter in read_file:
        if letter not in punctuation:
            new_file += letter

    #turn to lower case
    new_file = new_file.lower()

    # Split single string into list of words
    word_list = new_file.split()

    # Transverse list and Create frequency table
    dict_word_number = dict()
    for word in word_list:
        #dict_word_number[word] = dict_word_number.get(word, 0) + 1
        dict_word_number[word] = len(word)

    # Turn dictionary items to list of tuples. (list of words and their counts)
    list_dictionary = list(dict_word_number.items())

    #Sort list of dictionary items (sort list of words and counts)
    #list_dictionary.sort()

    new_list = []
    for x, y in list_dictionary:
        swap = (y, x)
        new_list.append(swap)

    new_list.sort()


    # Now write in output format
        #First, create new file
    new_file_location = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\alice_word_length.txt"
    file_hd = open(new_file_location, "w")

        #Now, prepare a text layout to eb used for header and body in stg.format
        #method
    text_layout = "{0:<30} {1:<10}\n"

        #Secondly, create header and underline               # prepare table
    header = text_layout.format("Length", "Word")    #prepare the header format
    underline_header = "="*36 + "\n"                #Prepare the underline
    file_hd.write(header)                           #Write header
    file_hd.write(underline_header)                 #Underline header

        #Now, Write body of the table (words and their counts) using loop
    for key, value in new_list:
        length_word = text_layout.format(key, value)
        file_hd.write(length_word)

        #close the file
    file_hd.close()

    return file_hd

#test
#file = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\Alice adventures in Wonderland2.txt"
#print(words_length_counter(file))























