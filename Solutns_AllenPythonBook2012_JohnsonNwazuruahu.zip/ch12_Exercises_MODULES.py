

#   1.
'''  Open help for the calendar module.
    (a) Try the following:
    1 import calendar
    2 cal = calendar.TextCalendar() # Create an instance
    3 cal.pryear(2012) # What happens here?
    (b) Observe that the week starts on Monday. An adventurous CompSci student
    believes that it is better mental chunking to have his week start on Thursday,
    because then there are only two working days to the weekend, and every week
    has a break in the middle. Read the documentation for TextCalendar, and see
    how you can help him print a calendar that suits his needs.
    (c) Find a function to print just the month in which your birthday occurs this year.
    (d) Try this:
    1 d = calendar.LocaleTextCalendar(6, "SPANISH")
    2 d.pryear(2012)
    Try a few other languages, including one that doesn’t work, and see what happens.
    (e) Experiment with calendar.isleap. What does it expect as an argument? What
    does it return as a result? What kind of a function is this?
    Make detailed notes about what you learned from these exercises.
'''

"""
import calendar
cal = calendar.TextCalendar()
cal.pryear(2017)

#   b.
cal = calendar.TextCalendar(4)      #argument = day to start calendar week. mon = 0, sun = 6
cal.pryear(2017)

#   c.
cal = calendar.TextCalendar(6)      #set weekday to begin on sunday
cal.prmonth(2017, 4)

#   d.
d = calendar.LocaleTextCalendar(6, "ENGLISH")
d.pryear(2017)
"""








#   2.
'''Open help for the math module.
(a) How many functions are in the math module?
(b) What does math.ceil do? What about math.floor? (hint: both floor and
ceil expect floating point arguments.)
(c) Describe how we have been computing the same value as math.sqrt without
using the math module.
(d) What are the two data constants in the math module? '''

"""
#SOLN
#   a.          = Math Module has 42 functions

#   b.          = math.ceil: returns celeing of x && math.floor: returns floor of x

#   c.          We've been using functions to compute sqrt. specifically, using
#               ** 0.5

#   d.          2 data constants in math module = pi and e.
"""








#   3.









#   4.
'''
Create a module named mymodule1.py. Add attributes myage set to your current
age, and year set to the current year. Create another module named mymodule2.py.
Add attributes myage set to 0, and year set to the year you were born. Now create a
file named namespace_test.py. Import both of the modules above and write the
following statement:
1 print( (mymodule2.myage - mymodule1.myage) ==
2 (mymodule2.year - mymodule1.year) )
When you will run namespace_test.py you will see either True or False as
output depending on whether or not you’ve already had your birthday this year.
What this example illustrates is that out different modules can both have attributes named
myage and year. Because they’re in different namespaces, they don’t clash with one
another. When we write namespace_test.py, we fully qualify exactly which variable
year or myage we are referring to. '''

#SOLN

"""
Done on instructed modules. Lessons learnt on _name_ and _main_.
"""








#   7.
'''
Give the Python interpreter’s response to each of the following from a continuous interpreter
session:
>>> s = "If we took the bones out, it wouldn’t be crunchy, would it?"
>>> s.split()
>>> type(s.split())
>>> s.split("o")
>>> s.split("i")
>>> "0".join(s.split("o"))
Be sure you understand why you get each result. Then apply what you have learned to fill
in the body of the function below using the split and join methods of str objects:


1 def myreplace(old, new, s):
2 """ Replace all occurrences of old with new in s. """
3 ...
4
5
6 test(myreplace(",", ";", "this, that, and some other thing") ==
7 "this; that; and some other thing")
8 test(myreplace(" ", "**",
9 "Words will now be separated by stars.") ==
10 "Words**will**now**be**separated**by**stars.")
Your solution should pass the tests. '''

#SOLN
'''
s = "If we took the bones out, it wouldn’t be crunchy, would it?"
(s.split())

#               Above would give ["If", "we", "took", "the", "bones", "out,",
#                "it", "wouldn't", "be", "crunchy,", "would", "it"]

print(type(s.split()))         # This would give list

s.split("o")        # this uses "o" as teh delimiter, instead of whitespace
s.split("i")        #   this uses "i" as teh delimiter, instead of whitespace
"0".join(s.split("o"))  #replaces "o" with "0" in s. sort of like find and replace.
'''

def myreplace(old, new, s):
    """ Replace all occurrences of old with new in s. """
    #This is a SPLIT and JOIN operation. Can be executed as a single line. I
    #decide to use two lines; line 1 = SPLIT and line 2 = JOIN

    split_op = s.split(old)             #SPLIT process
    join_op = new.join(split_op)        #JOIN process
    return join_op


print(myreplace(" ", "**", "Words will now be separated by stars."))































