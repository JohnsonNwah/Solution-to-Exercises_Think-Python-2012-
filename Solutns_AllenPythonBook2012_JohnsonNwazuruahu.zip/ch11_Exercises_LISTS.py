

#   1.
#   What is the Python interpreter’s response to the following?
#   >>> list(range(10, 0, -2))
# The three arguments to the range function are start, stop, and step, respectively.
# In this example, start is greater than stop. What happens if start < stop and step <
# 0? Write a rule for the relationships among start, stop, and step.

#SOLN
# The range fuction suplies the numbers from 10, and counts backward in steps of 2
 # (i.e.  -ve means count backward), up until it gets to 0. Range actualy gives
 # 'the promise' i.e (10, 2).
 # The list function turns this into a list type. we now have 10, 8, 6, 4, 2
 # Note that 0 is not included as it is the stop number and hence not included.

# Qtns 2
#If start < stop and step < 0
# for the above, the semantics is wrong. Cos, step size is meannt to count backward,
# hence if start < stop, start woyld never get to stop. It would continue in -ve
# part of the line number, sort of.

# So, Rule would be: Program would run if:
# (1) Start > stop AND step < 0     OR
# (1) Start < stop AND step > 0     ELSE
# (1) Return indeterminate error.







#   2.
# Consider this fragment of code:
#       1 import turtle
#       2
#       3 tess = turtle.Turtle()
#       4 alex = tess
#       5 alex.color("hotpink")
# Does this fragment create one or two turtle instances? Does setting the color
 # of alex also change the color of tess? Explain in detail.

#SOLN
# Yes, the fragent creates two instances, i.e tess and alex;  both pointing or
# referring to same object or value.  Specically, an Alias is created.

#Yes, setting colour of alex changes tess colour, since being alias, a change in
# one affects all.







#   3.
# Draw a state snapshot for a and b before and after the third line of the
# following Python code is executed:
# 1     a = [1, 2, 3]
# 2     b = a[:]
# 3     b[0] = 5

#SOLN
#   Before 3rd line is executed:        a = [1, 2, 3]
#                                       b = [1, 2, 3]
# (b is a clone of copy of a, so they are two instances pointing to 2 different values)
#   After 3rd line is executed:         a = [1, 2, 3]
#                                       b = [5, 2, 3]







#   4.
#What will be the output of the following program?
#1      this = ["I", "am", "not", "a", "crook"]
# 2     that = ["I", "am", "not", "a", "crook"]
#3          print("Test 1: {0}".format(this is that))
#   4 that = this
#   5 print("Test 2: {0}".format(this is that))

# SOLN
# first print is :          Test 1: False
#       This is beacuse they are two variables pointing to different mutable objects
#       (If it was a string (immutable), python would have assigned them to same
#       object since they have same value. But in this case, being strings, they
#       point to different objects.)

#second print is :          Test 3: True
# Now, "that" has been made an alias of "this" so, they both now point to "this"'s
# original value.







#   5.
# Lists can be used to represent mathematical vectors. In this exercise and several that
# follow you will write functions to perform standard operations on vectors. Create a script
# named vectors.py and write Python code to pass the tests in each case.
# Write a function add_vectors(u, v) that takes two lists of numbers of the same
# length, and returns a new list containing the sums of the corresponding elements of each:
#1 test(add_vectors([1, 1], [1, 1]) == [2, 2])
#2 test(add_vectors([1, 2], [1, 4]) == [2, 6])
#3 test(add_vectors([1, 2, 1], [1, 4, 3]) == [2, 6, 4])

#SOLN
# This is like creating a new list. So, I'm gonna need empty list here.
# Also, I'll use while loop.

def add_vectors(u, v):
    """ Fn that adds corresponding elements in list u and v, of same length and
    returns a list of their corresponding element"""

    counter = 0                 # reqd for our while loop
    result = []                 #reqd for the buildingthe new list+


    if len(u) == len(v):        #first, check they have same length
        while counter < len(u):     #set loop count using any list length
            result += [u[counter] + v[counter]]     #add and concantenate
            counter += 1
        return result
    else:
        return ("Your lists don't have same length")

#print(add_vectors([1, 1], [1, 1]))








#   6.
# Write a function scalar_mult(s, v) that takes a number, s, and a list, v
# and returns the scalar multiple of v by s. :
#1      test(scalar_mult(5, [1, 2]) == [5, 10])
#2      test(scalar_mult(3, [1, 0, -1]) == [3, 0, -3])
#3      test(scalar_mult(7, [3, 0, 5, 11, 2]) == [21, 0, 35, 77, 14])

# As usual, we build a new list for the result again. so, we use empty list again [].
#Also, I use a for loop this time around. so, no need of a counter, as for loop
# woudl give me each element of the list.

def scalar_mult(s, v):
    """ Fn that multiples a list v by a number "s". """
    result = []

    for i in v:
        result += [s * i]
    return result


# print(scalar_mult(3, [1, 0, -1]))








#   7.
#Write a function dot_product(u, v) that takes two lists of numbers of the same
#   length, and returns the sum of the products of the corresponding elements
#   of each (the dot_product).
#1      test(dot_product([1, 1], [1, 1]) == 2)
#2      test(dot_product([1, 2], [1, 4]) == 9)
#3      test(dot_product([1, 2, 1], [1, 4, 3]) == 12)

#SOLN

def dot_product(u, v):
    """ Fn to return dot product of correspondong elements in lists u and v,
    which both have equal lengths"""

    result = 0
    if len(u) == len(v):
        for i in range(len(u)):     # no variable assignment. just loop count and index provision
            product = u[i] * v[i]
            result = result + product
        return result
    else:
        return "Given lists are not of same length"

#print(dot_product([1, 2], [1, 4]))








#   8.
#   Extra challenge for the mathematically inclined: Write a function
# cross_product(u, v) that takes two lists of numbers of length 3 and returns
# their cross product. You should write your own tests.

#SOLN
# Try later.








#   9.
# Describe the relationship between " ".join(song.split()) and song in the
# fragment of code below. Are they the same for all strings assigned to song? When
# would they be different?
#1          song = "The rain in Spain..."

#SOLN
#First, recall; Split = String >> List of words/substrings          WHILE
#               join =  List of substrings >>> Strings

# So, song.split() will give;           ["The", "rain", "in", "Spain..."]
# " ".join(song.split()) will give;     "The rain in Spain"
# so, the rrelationship is that they have same value.

#They'll be different if ther's no space between the quoatation maerks. i.e.
#    "" instead of " "

#   TEST ABOVE IN BELOW CODES.

#song = "The rain in Spain..."              Uncomment this and next 4 stmts to test
#print(song)
#print(song.split())

#separator = " "
#print(separator.join(song.split()))








#   10.
# Write a function replace(s, old, new) that replaces all occurrences of old with
# new in a string s:

#SOLN.
#Recall, strings are immutable. we can't change its elements. we can only create
# a new string with the features of what we have.
# As usual, we start with empty string and build our string accordingly.

def replace(s, old, new):               # for single characters replacement
    """ Fn that replaces "old" with "new" in string s"""
    #Use FOR Loop tp transverse your string"

    new_string = ""
    for i in s:
        if old in i:
            new_string = new_string + new
        else:
            new_string = new_string + i
    return new_string


#print(replace("Mississippi", "i", "I"))
#s = "I love spom! Spom is my favorite food. Spom, spom, yum!"
#print(replace(s, "o", "a"))

#2:     for substrings and also single character replacement too

def replace2(s, old, new):
    """ Fn that replaces "old" with "new" in string s. old and new can be single
     character or substring"""

    s_to_list = s.split(old)          #splits s using "old" as delimiter. actn also removes old
    result = new.join(s_to_list)    #new would be the character to be added when joining
    return result

s = "I love spom! Spom is my favorite food. Spom, spom, yum!"
print(replace2("Tick Tock Pock Cock Fock Sock", "ck", "ger"))










#   11.
# Suppose you want to swap around the values in two variables. You decide to
# factor this out into a reusable function, and write this code:
#1      def swap(x, y): # Incorrect version
#2      print("before swap statement: x:", x, "y:", y)
#3      (x, y) = (y, x)
#4      print("after swap statement: x:", x, "y:", y)
#5
#6      a = ["This", "is", "fun"]
#7      b = [2,3,4]
#8      print("before swap function call: a:", a, "b:", b)
#9      swap(a, b)
#10     print("after swap function call: a:", a, "b:", b)
# Run this program and describe the results. Oops! So it didn’t do what
# you intended! Explain why not. Using a Python visualizer like the one at
# http://netserv.ict.ru.ac.za/python3_viz may help you build a good conceptual model of
# what is going on. What will be the values of a and b after the call to swap?

'''
def swap(x, y): # Incorrect version
    print("before swap statement: x:", x, "y:", y)
    (x, y) = (y, x)
    print("after swap statement: x:", x, "y:", y)

a = ["This", "is", "fun"]
b = [2,3,4]
print("before swap function call: a:", a, "b:", b)
swap(a, b)
print("after swap function call: a:", a, "b:", b)
'''

#SOLN
# Actually, a and b still maintained their global values, and that was what was
# called in last function call.




















