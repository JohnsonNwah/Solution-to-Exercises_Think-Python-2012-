


#   1.
'''
Write a program that reads a file and writes out a new file with the lines in
reversed order.
(i.e. the first line in the old file becomes the last one in the new file.)'''

#SOLN
''' I did this by
1)  using readlines to read all the file content into a list of strings,
where each string represents a file line.
2) I then got the count of the list elements, since no of filelines = no of list elements
3) I wrote element at last index first, since it doesn't have a newline character
4) using loop, i started writing out the elements of this list, startng frm 2nd to
    last line'''

def reversefile(oldfile, newfile):
    """ Function that reverses line in a file"""

    #create fine handles
    file_handle1 = open(oldfile, "r")
    file_handle2 = open(newfile, "w")

    #read all contents in old file, as a list of strings
    read_old = file_handle1.readlines()
    #print(read_old)
    no_of_lines = len(read_old) - 1     #get no of lines in old (since no of filelines = no of list elements
    print(no_of_lines)
    counter = no_of_lines

    file_handle2.write(read_old[counter])
    file_handle2.write("\n")
    while counter > 0:
        file_handle2.write(read_old[counter-1])
        counter -= 1



    file_handle1.close()
    file_handle2.close()


#test function
x = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\copiedfrmtextbk.txt"
y = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\myreversedfile2.txt"

reversefile(x, y)








#   2.
''' Write a program that reads a file and prints only those lines that contain the substring
    snake.'''

#SOLN
'''
1)  Read file line by line
2) In each line, check if snake is there, either using "in" or "not in" appropriately
3) depending on test operator used above, continue to next line or write to new file accordingly
'''

def print_snake(oldfile, newfile):
    """ Function to print lines in a file containing snake"""

    #create file objects/handles
    file_handle1 = open(oldfile)
    file_handle2 = open(newfile, "w")

    while True:
        read_op = file_handle1.readline()
        if len(read_op) == 0:
            break
        if "snake" in read_op:
            file_handle2.write(read_op)

    file_handle1.close()
    file_handle2.close()


#test function
x = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\snake_original_file.txt"
y = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\snakeonlyfile.txt"

print_snake(x, y)








#   3.
'''
    Write a program that reads a text file and produces an output file which is a copy of the
    file, except the first five columns of each line contain a four digit line number, followed by
    a space. Start numbering the first line in the output file at 1. Ensure that every line number
    is formatted to the same width in the output file. Use one of your Python programs as
    test data for this exercise: your output should be a printed and numbered listing of the
    Python program.'''

#SOLN
'''
1) As usual, create 2 file handles
2) Create an empty string containing 5 spaces (to be ur 5 columns)
3) create a counter, starting from 1. the counter is to be implemented in each line
    and then incremented (for next line)
4) concantenate
'''

def numbered_text(oldfile, newfile):
    """ A function that prints a numbered listing of input file, as output file"""

    #create file objects/handles
    file_handle1 = open(oldfile)
    file_handle2 = open(newfile, "w")

    spacing = " "
    counter = 1

    while True:
        read_op = file_handle1.readline()
        if len(read_op) == 0:
            break
        numbering = str(counter)
        file_handle2.write(numbering + spacing + read_op)
        counter += 1

    file_handle1.close()
    file_handle2.close()



#test function
x = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\ch12_Exercises_MODULES.py"
y = r"C:\Users\JOHNSON\Documents\STUDIES\PHD STUFFS\LEARNING PROGRAMMING\Think like a scientist\numberedprogram.txt"

numbered_text(x, y)


























