

#   1
'''Write a function named readposint that uses the input dialog to prompt the user
for a positive integer and then checks the input to confirm that it meets the requirements.
It should be able to handle inputs that cannot be converted to int, as well as negative
ints, and edge cases (e.g. when the user closes the dialog, or does not enter anything at
all.)'''
# SOLN
# I'm gonna use raise here

def readposint():
    """ Fn to accept positive integar i/p frm users via a dialogue box. Else,
    it tells them to recheck"""

    user_input = int(input("Please supply your input: "))
    if type(user_input) != int:
        raise TypeError ("You suppied a string. Please input positive integar")
    elif user_input < 0:
        raise ValueError ("You suppied a negative integar. Please input positive integar")
    elif user_input == 0:
        raise ValueError ("You suppied zero. Please input positive integar")
    elif user_input == None:
        raise ValueError (" You entered no value. Please input positive integar")
    else:
        return("You currently entered a positive integar of value: ", user_input)


print(readposint())
